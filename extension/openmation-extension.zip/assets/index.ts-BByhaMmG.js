import{g as O,e as Be,A as Q}from"./api-BNbQHRAB.js";const S="openmation-panel",T="openmation-cursor";let u={mode:"ready",eventCount:0,duration:0,startTime:0},D=null;function Ue(){_();const e=document.createElement("div");e.id=S,e.innerHTML=tt();const t=document.createElement("style");return t.id=`${S}-styles`,t.textContent=nt(),document.head.appendChild(t),document.body.appendChild(e),Ge(e),Je(e),e}function _(){const e=document.getElementById(S);e&&e.remove();const t=document.getElementById(`${S}-styles`);t&&t.remove(),P()}function J(e){u={...u,...e},e.mode==="recording"&&!D?G():(e.mode==="paused"||e.mode==="ready"||e.mode==="saving")&&P(),$()}function qe(e,t,n){u={mode:n?"paused":"recording",eventCount:e,duration:t,startTime:Date.now()-t},n||G(),$(),me()}function G(){P(),u.startTime=Date.now()-u.duration,D=setInterval(()=>{u.mode==="recording"&&(u.duration=Date.now()-u.startTime,Ye())},100)}function P(){D&&(clearInterval(D),D=null)}function Ye(){const e=document.querySelector(".sa-duration");e&&(e.textContent=W(u.duration))}function $(){const e=document.getElementById(S);if(!e)return;const t=e.querySelector(".sa-status-dot"),n=e.querySelector(".sa-status-text");if(t&&n)switch(t.className="sa-status-dot",u.mode){case"recording":t.classList.add("sa-recording"),n.textContent="Recording";break;case"paused":t.classList.add("sa-paused"),n.textContent="Paused";break;case"saving":n.textContent="Save Recording";break;default:n.textContent="Ready"}const o=e.querySelector(".sa-event-count"),a=e.querySelector(".sa-duration");o&&(o.textContent=`${u.eventCount} action${u.eventCount!==1?"s":""}`),a&&(a.textContent=W(u.duration));const i=e.querySelector(".sa-pause-icon");i&&(i.innerHTML=u.mode==="paused"?et():he())}function me(){const e=document.getElementById(S);if(!e)return;const t=e.querySelector(".sa-start-view"),n=e.querySelector(".sa-recording-view"),o=e.querySelector(".sa-save-view");t&&(t.style.display="none"),n&&(n.style.display="block"),o&&(o.style.display="none")}function Xe(){const e=document.getElementById(S);if(!e)return;const t=e.querySelector(".sa-start-view"),n=e.querySelector(".sa-recording-view"),o=e.querySelector(".sa-save-view");t&&(t.style.display="none"),n&&(n.style.display="none"),o&&(o.style.display="block");const a=e.querySelector(".sa-event-count-final"),i=e.querySelector(".sa-duration-final");a&&(a.textContent=`${u.eventCount} action${u.eventCount!==1?"s":""}`),i&&(i.textContent=W(u.duration));const r=e.querySelector(".sa-name-input");r&&setTimeout(()=>r.focus(),100)}function W(e){const t=Math.floor(e/1e3),n=Math.floor(t/60),o=t%60;return`${n.toString().padStart(2,"0")}:${o.toString().padStart(2,"0")}`}function Ge(e){e.querySelector(".sa-start-btn")?.addEventListener("click",We),e.querySelector(".sa-pause-btn")?.addEventListener("click",Ve),e.querySelector(".sa-stop-btn")?.addEventListener("click",ze),e.querySelector(".sa-save-btn")?.addEventListener("click",ce),e.querySelector(".sa-discard-btn")?.addEventListener("click",Ke),e.querySelector(".sa-close-btn")?.addEventListener("click",je),e.querySelector(".sa-name-input")?.addEventListener("keydown",t=>{t.key==="Enter"&&ce()})}async function We(){chrome.runtime.sendMessage({type:"START_RECORDING_FROM_PANEL"}),u.mode="recording",u.eventCount=0,u.duration=0,G(),$(),me()}async function Ve(){u.mode==="paused"?(chrome.runtime.sendMessage({type:"RESUME_RECORDING"}),u.mode="recording",G()):(chrome.runtime.sendMessage({type:"PAUSE_RECORDING"}),u.mode="paused",P()),$()}async function ze(){P(),u.mode="saving",$(),Xe()}async function ce(){const e=document.getElementById(S),n=e?.querySelector(".sa-name-input")?.value.trim()||`Recording ${new Date().toLocaleString()}`,o=e?.querySelector(".sa-save-btn");o&&(o.disabled=!0,o.textContent="Saving..."),chrome.runtime.sendMessage({type:"STOP_RECORDING_WITH_NAME",name:n},a=>{a?.shareUrl&&navigator.clipboard.writeText(a.shareUrl).then(()=>{le(a.shareUrl)}).catch(()=>{le(a.shareUrl,!1)}),setTimeout(()=>{_()},3e3)})}function le(e,t=!0){const n=document.getElementById("openmation-success-toast");n&&n.remove();const o=document.createElement("div");o.id="openmation-success-toast",o.innerHTML=`
    <div class="om-toast-content">
      <div class="om-toast-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M20 6L9 17l-5-5"/>
        </svg>
      </div>
      <div class="om-toast-text">
        <div class="om-toast-title">Automation saved! ${t?"✓ Link copied":""}</div>
        <div class="om-toast-url">${e}</div>
      </div>
      <button class="om-toast-copy" onclick="navigator.clipboard.writeText('${e}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
        </svg>
      </button>
    </div>
  `;const a=document.createElement("style");a.id="openmation-success-toast-styles",a.textContent=`
    #openmation-success-toast {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483647;
      animation: om-toast-enter 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes om-toast-enter {
      from {
        opacity: 0;
        transform: translateX(-50%) translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
    }
    
    .om-toast-content {
      display: flex;
      align-items: center;
      gap: 12px;
      background: #ffffff;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 14px;
      padding: 14px 18px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.06);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    .om-toast-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.1);
      color: #10B981;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .om-toast-text {
      flex: 1;
      min-width: 0;
    }
    
    .om-toast-title {
      font-size: 14px;
      font-weight: 600;
      color: #1a1a1a;
      margin-bottom: 2px;
    }
    
    .om-toast-url {
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
      font-family: monospace;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 300px;
    }
    
    .om-toast-copy {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.6);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
      flex-shrink: 0;
    }
    
    .om-toast-copy:hover {
      background: rgba(0, 0, 0, 0.08);
      color: rgba(0, 0, 0, 0.8);
    }
  `,document.head.appendChild(a),document.body.appendChild(o),setTimeout(()=>{o.remove(),a.remove()},5e3)}function Ke(){chrome.runtime.sendMessage({type:"STOP_RECORDING"}),_()}function je(){if(u.mode==="recording"||u.mode==="paused"){if(!confirm("Stop recording and discard?"))return;chrome.runtime.sendMessage({type:"STOP_RECORDING"})}_()}function Je(e){const t=e.querySelector(".sa-panel-header");if(!t)return;let n=!1,o=0,a=0,i=0,r=0;t.addEventListener("mousedown",s=>{if(s.target.closest("button")||s.target.closest("input"))return;n=!0,o=s.clientX,a=s.clientY;const c=e.getBoundingClientRect();i=c.left,r=c.top,t.style.cursor="grabbing",s.preventDefault()}),document.addEventListener("mousemove",s=>{if(!n)return;const c=s.clientX-o,d=s.clientY-a;let g=i+c,p=r+d;const C=window.innerWidth-e.offsetWidth-10,x=window.innerHeight-e.offsetHeight-10;g=Math.max(10,Math.min(g,C)),p=Math.max(10,Math.min(p,x)),e.style.left=`${g}px`,e.style.top=`${p}px`,e.style.right="auto"}),document.addEventListener("mouseup",()=>{n&&(n=!1,t.style.cursor="grab")})}function Ze(){u.eventCount++;const e=document.querySelector(".sa-event-count");e&&(e.textContent=`${u.eventCount} action${u.eventCount!==1?"s":""}`,e.style.transform="scale(1.05)",setTimeout(()=>{e.style.transform="scale(1)"},100))}function Qe(){const e=document.getElementById(T);e&&e.remove();const t=document.createElement("div");t.id=T,t.innerHTML=`
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M5.5 3.5L20 11.5L12 14L9 21L5.5 3.5Z" fill="#3B82F6" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>
    </svg>
    <div class="sa-cursor-ripple"></div>
  `;const n=document.createElement("style");return n.id=`${T}-styles`,n.textContent=`
    #${T} {
      position: fixed;
      pointer-events: none;
      z-index: 2147483646;
      transform: translate(-3px, -3px);
      transition: left 16ms linear, top 16ms linear;
      filter: drop-shadow(0 2px 8px rgba(59, 130, 246, 0.3));
    }
    .sa-cursor-ripple {
      position: absolute;
      top: 10px;
      left: 10px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(59, 130, 246, 0.4);
      transform: translate(-50%, -50%) scale(0);
      opacity: 0;
    }
    .sa-cursor-ripple.active {
      animation: sa-ripple 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    @keyframes sa-ripple {
      0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(2.5); opacity: 0; }
    }
  `,document.head.appendChild(n),document.body.appendChild(t),t}function V(e,t){const n=document.getElementById(T);n&&(n.style.left=`${e}px`,n.style.top=`${t}px`)}function U(){const e=document.querySelector(`#${T} .sa-cursor-ripple`);e&&(e.classList.remove("active"),e.offsetWidth,e.classList.add("active"))}function ee(){document.getElementById(T)?.remove(),document.getElementById(`${T}-styles`)?.remove()}function et(){return'<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"/></svg>'}function he(){return'<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="4" width="5" height="16" rx="1"/><rect x="14" y="4" width="5" height="16" rx="1"/></svg>'}function tt(){return`
    <div class="sa-panel-inner">
      <div class="sa-panel-header">
        <div class="sa-brand">
          <div class="sa-logo">
            <img src="${chrome.runtime.getURL("icons/icon48.png")}" alt="Openmation" width="24" height="24" style="object-fit: contain;" />
          </div>
          <span class="sa-title">Openmation</span>
        </div>
        <button class="sa-close-btn" title="Close">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
      
      <div class="sa-panel-body">
        <!-- Ready State -->
        <div class="sa-start-view">
          <button class="sa-start-btn">
            <div class="sa-start-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <circle cx="12" cy="12" r="8"/>
              </svg>
            </div>
            <span>Start Recording</span>
          </button>
          <p class="sa-hint">Click to begin capturing your actions</p>
        </div>
        
        <!-- Recording State -->
        <div class="sa-recording-view" style="display: none;">
          <div class="sa-status-bar">
            <div class="sa-status">
              <div class="sa-status-dot sa-recording"></div>
              <span class="sa-status-text">Recording</span>
            </div>
            <div class="sa-stats">
              <span class="sa-event-count">0 actions</span>
              <span class="sa-divider">·</span>
              <span class="sa-duration">00:00</span>
            </div>
          </div>
          
          <div class="sa-controls">
            <button class="sa-pause-btn" title="Pause">
              <span class="sa-pause-icon">${he()}</span>
            </button>
            <button class="sa-stop-btn">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="6" width="12" height="12" rx="2"/>
              </svg>
              <span>Finish</span>
            </button>
          </div>
        </div>
        
        <!-- Save State -->
        <div class="sa-save-view" style="display: none;">
          <div class="sa-save-header">
            <div class="sa-save-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 6L9 17l-5-5"/>
              </svg>
            </div>
            <div class="sa-save-info">
              <span class="sa-event-count-final">${u.eventCount} actions</span>
              <span class="sa-divider">·</span>
              <span class="sa-duration-final">${W(u.duration)}</span>
            </div>
          </div>
          
          <input type="text" class="sa-name-input" placeholder="Name your automation..." autocomplete="off" spellcheck="false"/>
          
          <div class="sa-save-actions">
            <button class="sa-discard-btn">Discard</button>
            <button class="sa-save-btn">Save</button>
          </div>
        </div>
      </div>
    </div>
  `}function nt(){return`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
    
    #${S} {
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
      font-size: 13px;
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      animation: sa-panel-enter 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes sa-panel-enter {
      from {
        opacity: 0;
        transform: translateY(-8px) scale(0.96);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }
    
    .sa-panel-inner {
      background: #ffffff;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 16px;
      box-shadow: 
        0 0 0 1px rgba(0, 0, 0, 0.04),
        0 8px 40px rgba(0, 0, 0, 0.12),
        0 2px 8px rgba(0, 0, 0, 0.06);
      overflow: hidden;
      min-width: 260px;
      color: #1a1a1a;
    }
    
    /* Header */
    .sa-panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 14px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      cursor: grab;
      user-select: none;
    }
    
    .sa-brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .sa-logo {
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .sa-logo img {
      width: 24px;
      height: 24px;
      object-fit: contain;
    }
    
    .sa-title {
      font-weight: 600;
      font-size: 14px;
      background: linear-gradient(135deg, #06B6D4 0%, #3B82F6 50%, #2563EB 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      letter-spacing: -0.02em;
    }
    
    .sa-close-btn {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      border: none;
      background: transparent;
      color: rgba(0, 0, 0, 0.4);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    
    .sa-close-btn:hover {
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.7);
    }
    
    /* Panel Body */
    .sa-panel-body {
      padding: 14px;
    }
    
    /* Start View */
    .sa-start-view {
      text-align: center;
    }
    
    .sa-start-btn {
      width: 100%;
      height: 48px;
      border-radius: 12px;
      border: 1.5px solid rgba(0, 0, 0, 0.1);
      background: #ffffff;
      color: #1a1a1a;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.2s ease;
    }
    
    .sa-start-btn:hover {
      border-color: rgba(59, 130, 246, 0.3);
      background: rgba(59, 130, 246, 0.04);
    }
    
    .sa-start-icon {
      color: #EF4444;
    }
    
    .sa-hint {
      margin: 12px 0 0 0;
      font-size: 11px;
      color: rgba(0, 0, 0, 0.45);
    }
    
    /* Recording View */
    .sa-status-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }
    
    .sa-status {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .sa-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: rgba(0, 0, 0, 0.2);
    }
    
    .sa-status-dot.sa-recording {
      background: #EF4444;
      animation: sa-pulse 1.2s ease-in-out infinite;
    }
    
    .sa-status-dot.sa-paused {
      background: #F59E0B;
    }
    
    @keyframes sa-pulse {
      0%, 100% { 
        opacity: 1;
        box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
      }
      50% { 
        opacity: 0.8;
        box-shadow: 0 0 0 5px rgba(239, 68, 68, 0);
      }
    }
    
    .sa-status-text {
      font-size: 12px;
      font-weight: 500;
      color: #1a1a1a;
    }
    
    .sa-stats {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
      font-variant-numeric: tabular-nums;
    }
    
    .sa-divider {
      color: rgba(0, 0, 0, 0.2);
    }
    
    .sa-event-count {
      transition: transform 0.1s ease;
    }
    
    /* Controls */
    .sa-controls {
      display: flex;
      gap: 8px;
    }
    
    .sa-pause-btn {
      width: 44px;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.7);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    
    .sa-pause-btn:hover {
      background: rgba(0, 0, 0, 0.08);
    }
    
    .sa-stop-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: #1a1a1a;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    
    .sa-stop-btn:hover {
      background: #2a2a2a;
    }
    
    /* Save View */
    .sa-save-view {
      animation: sa-fade-in 0.2s ease;
    }
    
    @keyframes sa-fade-in {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    .sa-save-header {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 12px;
    }
    
    .sa-save-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.1);
      color: #10B981;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .sa-save-info {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
    }
    
    .sa-name-input {
      width: 100%;
      height: 44px;
      padding: 0 14px;
      border-radius: 10px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      background: #ffffff;
      color: #1a1a1a;
      font-size: 13px;
      font-family: inherit;
      outline: none;
      transition: all 0.15s ease;
      box-sizing: border-box;
    }
    
    .sa-name-input::placeholder {
      color: rgba(0, 0, 0, 0.35);
    }
    
    .sa-name-input:focus {
      border-color: rgba(59, 130, 246, 0.5);
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    .sa-save-actions {
      display: flex;
      gap: 8px;
      margin-top: 12px;
    }
    
    .sa-discard-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.6);
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    
    .sa-discard-btn:hover {
      background: rgba(0, 0, 0, 0.08);
      color: rgba(0, 0, 0, 0.8);
    }
    
    .sa-save-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: #1a1a1a;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    
    .sa-save-btn:hover {
      background: #2a2a2a;
    }
    
    .sa-save-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `}async function te(){return new Promise((e,t)=>{chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOT"},n=>{if(chrome.runtime.lastError){t(new Error(chrome.runtime.lastError.message));return}if(n?.error){t(new Error(n.error));return}n?.screenshot?e(n.screenshot):t(new Error("No screenshot returned"))})})}function ot(e){const t=e.getBoundingClientRect(),n=window.getComputedStyle(e),o=n.backgroundColor,a=n.color,i=o!=="rgba(0, 0, 0, 0)"?o:a,r=e.parentElement;let s="";r&&(s=Array.from(r.children).filter(I=>I!==e&&I instanceof HTMLElement).map(I=>I.innerText?.trim()).filter(I=>I&&I.length<100).slice(0,3).join(" | "));const c=window.innerWidth,d=window.innerHeight,g=t.left+t.width/2,p=t.top+t.height/2;let C=g<c/3?"left":g>c*2/3?"right":"center";const k=`${p<d/3?"top":p>d*2/3?"bottom":"middle"}-${C}`;return{elementColor:i,elementSize:{width:t.width,height:t.height},surroundingText:s.slice(0,200),relativePosition:k,pageTitle:document.title,pageUrl:window.location.href}}function ne(e,t=1280,n=.7){return new Promise((o,a)=>{const i=new Image;i.onload=()=>{let r=i.width,s=i.height;r>t&&(s=s*t/r,r=t);const c=document.createElement("canvas");c.width=r,c.height=s;const d=c.getContext("2d");if(!d){a(new Error("Failed to get canvas context"));return}d.drawImage(i,0,0,r,s);const g=c.toDataURL("image/webp",n);o(g)},i.onerror=()=>a(new Error("Failed to load image")),i.src=e})}function at(e,t,n){return new Promise((o,a)=>{const i=new Image;i.onload=()=>{const r=i.width/n.width,s=i.height/n.height,c={x:t.x*r,y:t.y*s,width:t.width*r,height:t.height*s};c.x=Math.max(0,c.x),c.y=Math.max(0,c.y),c.width=Math.min(c.width,i.width-c.x),c.height=Math.min(c.height,i.height-c.y);const d=document.createElement("canvas");d.width=c.width,d.height=c.height;const g=d.getContext("2d");if(!g){a(new Error("Failed to get canvas context"));return}g.drawImage(i,c.x,c.y,c.width,c.height,0,0,c.width,c.height);const p=d.toDataURL("image/webp",.85);o(p)},i.onerror=()=>a(new Error("Failed to load image for cropping")),i.src=e})}const it={datepicker:{roles:["grid","gridcell","application"],classPatterns:[/datepicker/i,/calendar/i,/date-picker/i,/react-datepicker/i,/flatpickr/i,/pikaday/i],dataAttributes:["data-date","data-day","data-month","data-year"],tagNames:[]},timepicker:{roles:["listbox","grid"],classPatterns:[/timepicker/i,/time-picker/i,/time-select/i],dataAttributes:["data-time","data-hour","data-minute"],tagNames:[]},calendar:{roles:["grid","gridcell"],classPatterns:[/calendar/i,/month-view/i,/day-grid/i],dataAttributes:["data-calendar"],tagNames:[]},dropdown:{roles:["listbox","menu"],classPatterns:[/dropdown/i,/drop-down/i,/popover-content/i],dataAttributes:["data-radix-popper-content-wrapper","data-headlessui-state"],tagNames:[]},select:{roles:["listbox","combobox"],classPatterns:[/select/i,/selectbox/i],dataAttributes:["data-select"],tagNames:["SELECT"]},combobox:{roles:["combobox","listbox"],classPatterns:[/combobox/i,/combo-box/i],dataAttributes:["data-combobox"],tagNames:[]},autocomplete:{roles:["combobox","listbox"],classPatterns:[/autocomplete/i,/auto-complete/i,/typeahead/i,/suggestion/i],dataAttributes:["data-autocomplete",'data-testid*="suggestion"'],tagNames:[]},modal:{roles:["dialog","alertdialog"],classPatterns:[/modal/i,/dialog/i,/overlay/i],dataAttributes:["data-modal","data-dialog","data-radix-dialog-content"],tagNames:[]},dialog:{roles:["dialog","alertdialog"],classPatterns:[/dialog/i],dataAttributes:["data-dialog"],tagNames:["DIALOG"]},popover:{roles:["tooltip","dialog"],classPatterns:[/popover/i,/pop-over/i,/floating/i],dataAttributes:["data-popover","data-radix-popper"],tagNames:[]},tooltip:{roles:["tooltip"],classPatterns:[/tooltip/i,/tip/i],dataAttributes:["data-tooltip"],tagNames:[]},menu:{roles:["menu","menubar"],classPatterns:[/menu(?!item)/i,/nav-menu/i],dataAttributes:["data-menu"],tagNames:[]},submenu:{roles:["menu"],classPatterns:[/submenu/i,/sub-menu/i,/nested-menu/i],dataAttributes:["data-submenu"],tagNames:[]},"context-menu":{roles:["menu"],classPatterns:[/context-menu/i,/contextmenu/i,/right-click/i],dataAttributes:["data-context-menu"],tagNames:[]},tabs:{roles:["tablist","tab","tabpanel"],classPatterns:[/tabs?(?!le)/i,/tab-list/i],dataAttributes:["data-tabs","data-radix-tabs"],tagNames:[]},accordion:{roles:["region","button"],classPatterns:[/accordion/i,/collapsible/i],dataAttributes:["data-accordion","data-radix-accordion"],tagNames:[]},collapse:{roles:["region"],classPatterns:[/collapse/i,/expandable/i],dataAttributes:["data-collapse"],tagNames:[]},slider:{roles:["slider"],classPatterns:[/slider/i,/range-slider/i],dataAttributes:["data-slider"],tagNames:[]},range:{roles:["slider"],classPatterns:[/range/i],dataAttributes:["data-range"],tagNames:['INPUT[type="range"]']},stepper:{roles:["spinbutton"],classPatterns:[/stepper/i,/number-input/i,/quantity/i],dataAttributes:["data-stepper"],tagNames:[]},table:{roles:["table","grid"],classPatterns:[/table/i,/data-grid/i],dataAttributes:["data-table"],tagNames:["TABLE"]},grid:{roles:["grid","treegrid"],classPatterns:[/grid/i,/data-grid/i],dataAttributes:["data-grid"],tagNames:[]},list:{roles:["list","listbox"],classPatterns:[/list(?!en)/i,/items/i],dataAttributes:["data-list"],tagNames:["UL","OL"]},form:{roles:["form"],classPatterns:[/form/i],dataAttributes:["data-form"],tagNames:["FORM"]},search:{roles:["search","searchbox"],classPatterns:[/search/i],dataAttributes:["data-search"],tagNames:['INPUT[type="search"]']},none:{roles:[],classPatterns:[],dataAttributes:[],tagNames:[]}};function rt(e){const t=e.getAttribute("role")?.toLowerCase()||"",n=e.className?.toString()||"",o=e.tagName;for(const[a,i]of Object.entries(it))if(a!=="none"){if(i.roles.some(r=>t.includes(r.toLowerCase()))||i.classPatterns.some(r=>r.test(n)))return a;for(const r of i.dataAttributes)if(r.includes("*")){const s=r.split("*")[0];if(Array.from(e.attributes).some(c=>c.name.startsWith(s)))return a}else if(e.hasAttribute(r))return a;if(i.tagNames.includes(o))return a}return"none"}function st(e){let t=e,n=0;const o=15;for(;t&&n<o;){const a=rt(t);if(a!=="none")return ct(t,a);t=t.parentElement,n++}return null}function ct(e,t){const n=lt(e),o=O(e),a=ut(e),i=dt(e,t),r=pt(e,t);return{type:t,state:n,containerSelector:o,triggerSelector:a,currentValue:i,options:r}}function lt(e){const t=e.getAttribute("aria-expanded");if(t==="true")return"expanded";if(t==="false")return"collapsed";if(e.getAttribute("aria-hidden")==="true")return"closed";const o=e.getAttribute("data-state");if(o==="open")return"open";if(o==="closed")return"closed";if(e instanceof HTMLElement){const i=window.getComputedStyle(e);if(i.display==="none"||i.visibility==="hidden")return"closed"}const a=e.className?.toString()||"";return/\bopen\b|\bactive\b|\bshow\b|\bvisible\b/i.test(a)?"open":/\bclosed\b|\binactive\b|\bhidden\b/i.test(a)?"closed":"open"}function ut(e){const t=e.id;if(t){const o=document.querySelector(`[aria-controls="${t}"]`);if(o)return O(o)}const n=e.parentElement;if(n){const o=n.querySelectorAll('button, input, [role="button"], [tabindex="0"]');for(const a of o)if(a!==e&&!e.contains(a))return O(a)}}function dt(e,t){switch(t){case"datepicker":case"calendar":return e.querySelector('[aria-selected="true"], .selected, [data-selected="true"]')?.textContent?.trim();case"select":case"dropdown":case"combobox":return e.querySelector('[aria-selected="true"], .selected, option:checked')?.textContent?.trim();default:return}}function pt(e,t){if(!["select","dropdown","combobox","autocomplete","list"].includes(t))return;const n=[],o=e.querySelectorAll('[role="option"], option, li, [data-testid*="option"]');for(const a of o){const i=a.textContent?.trim();if(i&&i.length<100&&n.push(i),n.length>=20)break}return n.length>0?n:void 0}function gt(e){const t=[];let n=e.parentElement;for(;n&&n!==document.body;){if(ft(n)){const o=mt(n,e);t.push(o)}n=n.parentElement}return t}function ft(e){if(!(e instanceof HTMLElement))return!1;const t=window.getComputedStyle(e),n=t.overflowY,o=t.overflowX,a=(n==="scroll"||n==="auto")&&e.scrollHeight>e.clientHeight,i=(o==="scroll"||o==="auto")&&e.scrollWidth>e.clientWidth;return a||i}function mt(e,t){const n=e,o=window.getComputedStyle(e),a=(o.overflowY==="scroll"||o.overflowY==="auto")&&n.scrollHeight>n.clientHeight,i=(o.overflowX==="scroll"||o.overflowX==="auto")&&n.scrollWidth>n.clientWidth;let r="vertical";a&&i?r="both":i&&(r="horizontal");const s=e.getBoundingClientRect(),c=t.getBoundingClientRect(),d=c.top>=s.top&&c.bottom<=s.bottom&&c.left>=s.left&&c.right<=s.right;let g;if(!d){const p=c.top-s.top+n.scrollTop-s.height/2,C=c.left-s.left+n.scrollLeft-s.width/2;g={x:Math.max(0,Math.min(C,n.scrollWidth-n.clientWidth)),y:Math.max(0,Math.min(p,n.scrollHeight-n.clientHeight))}}return{selector:O(e),scrollDirection:r,currentScroll:{x:n.scrollLeft,y:n.scrollTop},maxScroll:{x:n.scrollWidth-n.clientWidth,y:n.scrollHeight-n.clientHeight},isElementVisible:d,scrollToReveal:g}}function ht(e){const t=[];let n=e,o=0;const a=15;for(;n&&n!==document.body&&o<a;){const i=bt(n);i&&t.unshift(i),n=n.parentElement,o++}return t}function bt(e){const t=e.getAttribute("role");if(t)return t;const n=e.tagName.toLowerCase();if(["form","nav","header","footer","main","aside","article","section"].includes(n))return n;const a=e.getAttribute("aria-label");if(a)return a.toLowerCase().replace(/\s+/g,"-");const i=e.className?.toString()||"",r=[/datepicker/i,/calendar/i,/dropdown/i,/modal/i,/dialog/i,/menu/i,/tabs?/i,/accordion/i,/stepper/i,/form/i,/search/i];for(const s of r)if(s.test(i))return s.source.toLowerCase().replace(/[\\^$]/g,"");return null}function wt(e){return{role:e.getAttribute("role")||void 0,label:e.getAttribute("aria-label")||e.getAttribute("aria-labelledby")?document.getElementById(e.getAttribute("aria-labelledby"))?.textContent?.trim():void 0,description:e.getAttribute("aria-description")||e.getAttribute("aria-describedby")?document.getElementById(e.getAttribute("aria-describedby"))?.textContent?.trim():void 0,expanded:e.getAttribute("aria-expanded")==="true"?!0:e.getAttribute("aria-expanded")==="false"?!1:void 0,selected:e.getAttribute("aria-selected")==="true"?!0:e.getAttribute("aria-selected")==="false"?!1:void 0,checked:e.getAttribute("aria-checked")==="true"?!0:e.getAttribute("aria-checked")==="false"?!1:void 0,disabled:e.getAttribute("aria-disabled")==="true"||e.disabled===!0,required:e.getAttribute("aria-required")==="true"||e.required===!0}}function yt(e){const t=[],n=e.getBoundingClientRect(),o=150,i=document.querySelectorAll('button, a, input, select, textarea, [role="button"], [role="link"], [tabindex="0"]');for(const r of i){if(r===e)continue;const s=r.getBoundingClientRect(),c=s.left+s.width/2,d=s.top+s.height/2,g=n.left+n.width/2,p=n.top+n.height/2;if(Math.sqrt(Math.pow(c-g,2)+Math.pow(d-p,2))>o)continue;let x;const k=c-g,K=d-p;Math.abs(K)>Math.abs(k)?x=K<0?"above":"below":x=k<0?"left":"right";const j=r.textContent?.trim().slice(0,50)||r.getAttribute("aria-label")||r.placeholder||"";if(j&&t.push({selector:O(r),text:j,position:x}),t.length>=8)break}return t}function xt(e){const t=gt(e),n=st(e),o=ht(e),a=yt(e),i=wt(e);return{preparationSteps:Et(t,n),scrollContainers:t,widgetContext:n||void 0,domPath:o,siblingElements:a,accessibilityInfo:i}}function Et(e,t){const n=[];t?.state==="closed"&&t.triggerSelector&&n.push(`Open the ${t.type} by clicking: ${t.triggerSelector}`);for(const o of e)!o.isElementVisible&&o.scrollToReveal&&n.push(`Scroll ${o.scrollDirection} in container ${o.selector} to position (${Math.round(o.scrollToReveal.x)}, ${Math.round(o.scrollToReveal.y)})`);return n}function Ct(e){const t=[];if(e.widgetContext&&(t.push(`Inside a ${e.widgetContext.type} (${e.widgetContext.state})`),e.widgetContext.currentValue&&t.push(`Current value: "${e.widgetContext.currentValue}"`)),e.domPath.length>0&&t.push(`Path: ${e.domPath.join(" > ")}`),e.scrollContainers.length>0){const n=e.scrollContainers.map(o=>`${o.scrollDirection} scroll container ${o.isElementVisible?"(visible)":"(needs scroll)"}`);t.push(`Scroll context: ${n.join(", ")}`)}if(e.siblingElements.length>0){const n=e.siblingElements.slice(0,3).map(o=>`"${o.text}" (${o.position})`).join(", ");t.push(`Nearby: ${n}`)}return e.accessibilityInfo.role&&t.push(`Role: ${e.accessibilityInfo.role}`),e.accessibilityInfo.label&&t.push(`Label: "${e.accessibilityInfo.label}"`),t.join(". ")}let m=!1,f=!1,E=[],N=[],L=[],A=0,H="",q=!1;async function be(){try{q=(await chrome.runtime.sendMessage({type:"GET_AI_STATUS"}))?.enabled??!1}catch{q=!1}}be();const vt=50;let ue=0;function St(e){const t=O(e),n=[],o={};if(e.id&&(n.push(`#${CSS.escape(e.id)}`),o.id=e.id),e.className&&typeof e.className=="string"){const r=e.className.trim().split(/\s+/).filter(s=>s&&!s.startsWith("sa-"));r.length>0&&n.push(`${e.tagName.toLowerCase()}.${r.map(s=>CSS.escape(s)).join(".")}`)}const a=e;a.getAttribute&&["name","data-testid","data-id","aria-label","placeholder","type","role"].forEach(r=>{const s=a.getAttribute(r);s&&(n.push(`${e.tagName.toLowerCase()}[${r}="${CSS.escape(s)}"]`),o[r]=s)});let i;if(e instanceof HTMLElement&&(e.tagName==="BUTTON"||e.tagName==="A")){const r=e.innerText?.trim().slice(0,50);r&&(i=r)}return{primary:t,fallbacks:n,textContent:i,attributes:o}}function Tt(e){const t=e.getBoundingClientRect();return{viewportX:t.left+t.width/2,viewportY:t.top+t.height/2,pageX:t.left+window.scrollX+t.width/2,pageY:t.top+window.scrollY+t.height/2,rect:{top:t.top,left:t.left,width:t.width,height:t.height}}}function w(e,t,n={}){const o={id:Be(),type:e,timestamp:Date.now()-A,scrollX:window.scrollX,scrollY:window.scrollY,...n};if(t){const a=St(t);o.selector=a.primary,o.selectorFallbacks=a.fallbacks,o.elementText=a.textContent,o.elementAttributes=a.attributes,o.tagName=t.tagName.toLowerCase();const i=Tt(t);o.elementRect=i.rect,o.pageX=i.pageX,o.pageY=i.pageY,t instanceof HTMLElement&&t.innerText&&(o.innerText=t.innerText.slice(0,100))}return L.length>0&&(o.mousePath=[...L],L=[]),o}function we(e){if(!m||f||v(e.target))return;const t=e.target,n=w("click",t,{x:e.clientX,y:e.clientY,pageX:e.pageX,pageY:e.pageY});y(n,t),Lt(e.clientX,e.clientY)}function ye(e){if(!m||f||v(e.target))return;const t=e.target,n=w("dblclick",t,{x:e.clientX,y:e.clientY,pageX:e.pageX,pageY:e.pageY});y(n,t)}function xe(e){if(!m||f||v(e.target))return;const t=e.target,n=w("mousedown",t,{x:e.clientX,y:e.clientY});y(n,t)}function Ee(e){if(!m||f||v(e.target))return;const t=e.target,n=w("mouseup",t,{x:e.clientX,y:e.clientY});y(n,t)}function Ce(e){if(!m||f)return;const t=Date.now();if(t-ue<vt)return;ue=t;const n={x:e.clientX,y:e.clientY,timestamp:t-A};N.push(n),L.push(n),L.length>30&&L.shift()}function ve(e){if(!m||f||v(e.target))return;const t=e.target,n=t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement;if(n||["Enter","Tab","Escape","Backspace","Delete","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Home","End","PageUp","PageDown"].includes(e.key)||e.ctrlKey||e.metaKey||e.altKey){const i=w("keydown",t,{key:e.key,keyCode:e.keyCode,value:n?t.value:void 0});y(i)}}function Se(e){if(!m||f||v(e.target))return;if(["Enter","Tab","Escape"].includes(e.key)){const n=w("keyup",e.target,{key:e.key,keyCode:e.keyCode});y(n)}}function Te(e){if(!m||f)return;const t=e.target;if(!t||v(t))return;const n=w("input",t,{value:t.value});n.isCheckpoint=!0,y(n)}function Re(e){if(!m||f)return;const t=e.target;if(!t||v(t))return;const n=w("change",t,{value:t.value});y(n,t)}function Ae(){if(!m||f)return;const e=E[E.length-1],t=Date.now()-A;if(e?.type==="scroll"&&t-e.timestamp<100){e.scrollX=window.scrollX,e.scrollY=window.scrollY,e.timestamp=t;return}const n=w("scroll",null,{scrollX:window.scrollX,scrollY:window.scrollY});y(n)}function ke(e){if(!m||f||v(e.target))return;const t=e.target;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement){const n=w("focus",t);y(n,t)}}function Ie(e){if(!m||f||v(e.target))return;const t=e.target;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement){const n=w("blur",t,{value:t.value});y(n)}}function Le(e){if(!m||f||v(e.target))return;const t=e.target,n=w("submit",t);y(n,t)}function Ne(){if(!m)return;const e=w("navigate",null,{url:window.location.href});y(e),Nt()}function v(e){return e?!!(e.closest("#openmation-panel")||e.closest("#openmation-cursor")):!1}async function y(e,t){if(q&&["click","dblclick","focus","change","submit"].includes(e.type)&&t){console.log("[Openmation] 📸 Capturing AI context for:",e.type);try{e.interactionContext=xt(t);const o=Ct(e.interactionContext);console.log("[Openmation] 🧩 Interaction context:",o),e.interactionContext.widgetContext&&console.log("[Openmation] 🎯 Widget detected:",{type:e.interactionContext.widgetContext.type,state:e.interactionContext.widgetContext.state,container:e.interactionContext.widgetContext.containerSelector?.slice(0,50)}),e.interactionContext.scrollContainers.length>0&&console.log("[Openmation] 📜 Scroll containers:",e.interactionContext.scrollContainers.map(r=>({direction:r.scrollDirection,visible:r.isElementVisible,needsScroll:!!r.scrollToReveal}))),e.interactionContext.preparationSteps.length>0&&console.log("[Openmation] 📋 Preparation steps:",e.interactionContext.preparationSteps);const[a,i]=await Promise.allSettled([Rt(),At(t)]);a.status==="fulfilled"?(e.screenshot=a.value,console.log("[Openmation] 📸 Screenshot captured:",Math.round(e.screenshot.length/1024),"KB")):console.warn("[Openmation] 📸 Screenshot failed:",a.reason),i.status==="fulfilled"?(e.elementCrop=i.value,console.log("[Openmation] 📸 Element crop captured:",Math.round(e.elementCrop.length/1024),"KB")):console.warn("[Openmation] 📸 Element crop failed:",i.reason),e.visualContext=ot(t),console.log("[Openmation] 📸 Visual context:",e.visualContext),e.screenshot&&e.elementCrop&&(console.log("[Openmation] 🤖 Requesting AI description with rich context..."),kt(e).catch(r=>{console.warn("[Openmation] 🤖 AI description failed:",r)}))}catch(o){console.warn("[Openmation] Failed to capture AI context:",o)}}E.push(e),e.isCheckpoint||Ze(),chrome.runtime.sendMessage({type:"EVENT_RECORDED",event:e}).catch(()=>{})}async function Rt(){const e=await te();return ne(e,1280,.7)}async function At(e){const t=e.getBoundingClientRect(),n=20,o=await new Promise((a,i)=>{chrome.runtime.sendMessage({type:"CAPTURE_ELEMENT_CROP",crop:{x:Math.max(0,t.left-n),y:Math.max(0,t.top-n),width:t.width+n*2,height:t.height+n*2},viewport:{width:window.innerWidth,height:window.innerHeight}},r=>{chrome.runtime.lastError?i(new Error(chrome.runtime.lastError.message)):r?.error?i(new Error(r.error)):a(r)})});return at(o.screenshot,o.crop,o.viewport)}async function kt(e){if(!(!e.screenshot||!e.elementCrop))try{const t=await new Promise((n,o)=>{chrome.runtime.sendMessage({type:"AI_DESCRIBE_ACTION",request:{screenshot:e.screenshot,elementCrop:e.elementCrop,actionType:e.type,coordinates:{x:e.x??0,y:e.y??0},value:e.value,interactionContext:e.interactionContext}},a=>{chrome.runtime.lastError?o(new Error(chrome.runtime.lastError.message)):n(a)})});if(t.success&&t.result){const n=E.findIndex(o=>o.id===e.id);if(n>=0){const o=E[n];o.aiDescription=t.result.description;const a={description:t.result.description,elementIdentification:t.result.elementIdentification||It(o),preparationSteps:t.result.preparationSteps||o.interactionContext?.preparationSteps||[],verificationSteps:t.result.verificationSteps||[],widgetType:t.result.widgetType||o.interactionContext?.widgetContext?.type,widgetContainer:t.result.widgetContainer||o.interactionContext?.widgetContext?.containerSelector};o.aiGuidance=a,console.log("[Openmation] 🤖 AI Guidance received:",{eventId:e.id,description:a.description,elementIdentification:a.elementIdentification?.slice(0,100),widgetType:a.widgetType,preparationSteps:a.preparationSteps.length,verificationSteps:a.verificationSteps.length})}}}catch(t){console.warn("[Openmation] Failed to get AI description:",t)}}function It(e){const t=[];e.tagName&&t.push(`A ${e.tagName} element`);const n=e.interactionContext?.accessibilityInfo;n?.role&&t.push(`with role="${n.role}"`),n?.label&&t.push(`labeled "${n.label}"`),e.elementText?t.push(`with text "${e.elementText}"`):e.innerText&&t.push(`containing text "${e.innerText.slice(0,30)}"`);const o=e.visualContext;o?.relativePosition&&t.push(`at ${o.relativePosition} of the page`);const a=e.interactionContext?.widgetContext;a&&t.push(`inside a ${a.type} (${a.state})`);const i=e.interactionContext?.siblingElements||[];if(i.length>0){const s=i[0];t.push(`${s.position} the element with text "${s.text}"`)}const r=e.interactionContext?.domPath||[];return r.length>0&&t.push(`in the path: ${r.join(" > ")}`),t.join(", ")||`Element at position (${e.x}, ${e.y})`}function Lt(e,t){const n=document.createElement("div");n.style.cssText=`
    position: fixed;
    left: ${e}px;
    top: ${t}px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: rgba(99, 102, 241, 0.3);
    transform: translate(-50%, -50%) scale(0);
    pointer-events: none;
    z-index: 2147483645;
    animation: sa-click-ripple 0.4s ease-out forwards;
  `;const o=document.createElement("style");o.textContent=`
    @keyframes sa-click-ripple {
      0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(3); opacity: 0; }
    }
  `,document.head.appendChild(o),document.body.appendChild(n),setTimeout(()=>{n.remove(),o.remove()},400)}function Nt(){const e={isRecording:m,isPaused:f,events:E,mouseMovements:N,startUrl:window.location.href,startTime:A,sessionId:H};try{localStorage.setItem("openmation_recording_state",JSON.stringify(e))}catch{}}function Me(){try{const e=localStorage.getItem("openmation_recording_state");if(!e)return!1;const t=JSON.parse(e);if(t.sessionId&&t.isRecording)return E=t.events||[],N=t.mouseMovements||[],A=t.startTime,H=t.sessionId,m=!0,f=t.isPaused,localStorage.removeItem("openmation_recording_state"),!0}catch{}return!1}async function de(e){if(await be(),console.log("[Openmation] AI enabled:",q),Me()){console.log("[Openmation] Resumed recording from previous page"),oe();return}m=!0,f=!1,E=[],N=[],L=[],A=Date.now(),H=e,oe(),console.log("[Openmation] Recording started")}function Mt(){f=!0,console.log("[Openmation] Recording paused")}function Ot(){f=!1,console.log("[Openmation] Recording resumed")}function Pt(){m=!1,f=!1,_t(),localStorage.removeItem("openmation_recording_state");const t={events:E.filter(n=>!n.isCheckpoint),mouseMovements:[...N],startUrl:window.location.href,duration:Date.now()-A};return E=[],N=[],console.log("[Openmation] Recording stopped:",t.events.length,"events"),t}function Dt(){return{isRecording:m,isPaused:f,events:E,mouseMovements:N,startUrl:window.location.href,startTime:A,sessionId:H}}function oe(){document.addEventListener("click",we,!0),document.addEventListener("dblclick",ye,!0),document.addEventListener("mousedown",xe,!0),document.addEventListener("mouseup",Ee,!0),document.addEventListener("mousemove",Ce,!0),document.addEventListener("input",Te,!0),document.addEventListener("change",Re,!0),document.addEventListener("keydown",ve,!0),document.addEventListener("keyup",Se,!0),document.addEventListener("focus",ke,!0),document.addEventListener("blur",Ie,!0),document.addEventListener("submit",Le,!0),window.addEventListener("scroll",Ae,!0),window.addEventListener("beforeunload",Ne)}function _t(){document.removeEventListener("click",we,!0),document.removeEventListener("dblclick",ye,!0),document.removeEventListener("mousedown",xe,!0),document.removeEventListener("mouseup",Ee,!0),document.removeEventListener("mousemove",Ce,!0),document.removeEventListener("input",Te,!0),document.removeEventListener("change",Re,!0),document.removeEventListener("keydown",ve,!0),document.removeEventListener("keyup",Se,!0),document.removeEventListener("focus",ke,!0),document.removeEventListener("blur",Ie,!0),document.removeEventListener("submit",Le,!0),window.removeEventListener("scroll",Ae,!0),window.removeEventListener("beforeunload",Ne)}function $t(){Me()&&(oe(),chrome.runtime.sendMessage({type:"RECORDING_RESUMED_ON_PAGE",sessionId:H,eventCount:E.length}).catch(()=>{}))}let B=!1,Y=!1,ae=!1;const b={INITIAL_DELAY:2e3,ELEMENT_WAIT_TIMEOUT:1e4,SCROLL_SETTLE_TIME:200,CLICK_SETTLE_TIME:100,KEY_DELAY:30,MIN_EVENT_GAP:20,AI_CONFIDENCE_THRESHOLD:.6},F={DROPDOWN_SELECTION:500,DATE_SELECTION:400,PANEL_TRIGGER:300,DEFAULT:100};function z(e){const t=[],n=e.match(/'([^']+)'/g);if(n)for(const s of n){const c=s.slice(1,-1);t.push(c),c.includes(",")&&t.push(...c.split(",").map(d=>d.trim()))}const o=e.match(/"([^"]+)"/g);if(o)for(const s of o)t.push(s.slice(1,-1));const a=e.match(/label(?:ed|)\s+['"]?([^'"]+)['"]?/gi);if(a)for(const s of a){const c=s.replace(/label(?:ed|)\s+['"]?/i,"").replace(/['"]$/,"");c&&t.push(c)}const i=e.match(/date\s+['"]?(\d{1,2})['"]?/gi);if(i)for(const s of i){const c=s.match(/\d+/);c&&t.push(c[0])}const r=e.match(/button\s+labeled\s+['"]?(\d+)['"]?/gi);if(r)for(const s of r){const c=s.match(/\d+/);c&&t.push(c[0])}return[...new Set(t)]}function Ht(e,t){if(!t)return!0;const n=z(t);if(n.length===0)return!0;const o=e.textContent?.trim().toLowerCase()||"",a=e.value?.toLowerCase()||"",i=e.getAttribute("aria-label")?.toLowerCase()||"",r=e.getAttribute("placeholder")?.toLowerCase()||"";for(const s of n){const c=s.toLowerCase();if(o.includes(c)||a.includes(c)||i.includes(c)||r.includes(c))return console.log("[Replayer] ✓ Text verification passed:",s),!0}return console.log("[Replayer] ⚠️ Text verification failed. Expected:",n,"Got:",o.substring(0,50)),!1}function Ft(e,t,n){if(!n)return null;const o=z(n);if(o.length===0)return null;const a=[20,40,60,80,100],i=[[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];for(const r of a)for(const[s,c]of i){const d=e+s*r,g=t+c*r,p=document.elementFromPoint(d,g);if(p&&R(p)){const C=p.textContent?.toLowerCase()||"";for(const x of o)if(C.includes(x.toLowerCase()))return console.log("[Replayer] 🎯 Found matching element at offset (",s*r,",",c*r,"):",x),X(d,g)||p}}console.log("[Replayer] 🔍 Searching all visible elements for:",o);for(const r of o){const s=document.querySelectorAll("*");for(const c of s){if(!R(c))continue;const d=c.textContent?.trim()||"",g=c.getAttribute("aria-label")||"";if(d.toLowerCase()===r.toLowerCase()||g.toLowerCase().includes(r.toLowerCase())){const p=c.getBoundingClientRect(),C=p.left+p.width/2,x=p.top+p.height/2,k=Math.sqrt(Math.pow(C-e,2)+Math.pow(x-t,2));if(k<200)return console.log("[Replayer] 🎯 Found matching element by text search:",r,"distance:",Math.round(k)),X(C,x)||c}}}return null}function Oe(e){const t=e.interactionContext?.widgetContext?.type||e.aiGuidance?.widgetType;if(t){if(["dropdown","select","combobox","autocomplete","menu","list"].includes(t))return"dropdown";if(["datepicker","calendar","timepicker"].includes(t))return"date";if(["modal","dialog","popover","stepper","accordion"].includes(t))return"panel"}const n=e.aiDescription?.toLowerCase()||"",o=e.selector?.toLowerCase()||"";return n.includes("list item")||n.includes("option")||n.includes("dropdown")||n.includes("suggestion")||o.includes("suggestion")||o.includes("option")||o.includes("listbox")?"dropdown":n.includes("date")||n.includes("calendar")||o.includes("calendar")||o.includes("datepicker")?"date":n.includes("misafir")||n.includes("guest")||n.includes("panel")||n.includes("ekleyin")||o.includes("stepper")?"panel":"default"}function Bt(e){switch(e){case"dropdown":return F.DROPDOWN_SELECTION;case"date":return F.DATE_SELECTION;case"panel":return F.PANEL_TRIGGER;default:return F.DEFAULT}}async function Ut(e){const t=e.interactionContext?.preparationSteps||e.aiGuidance?.preparationSteps||[];if(t.length!==0){console.log("[Replayer] 📋 Executing",t.length,"preparation steps");for(let n=0;n<t.length;n++){const o=t[n];console.log("[Replayer] 📋 Step",n+1,":",o);try{o.toLowerCase().includes("scroll")?await qt(o,e):o.toLowerCase().includes("open")||o.toLowerCase().includes("click")?await Yt(o,e):(o.toLowerCase().includes("wait")||o.toLowerCase().includes("ensure"))&&await Xt(o,e),await l(200),await h(300,80)}catch(a){console.warn("[Replayer] 📋 Preparation step failed:",o,a)}}}}async function qt(e,t){const n=t.interactionContext?.scrollContainers||[];for(const a of n)!a.isElementVisible&&a.scrollToReveal&&await re(a);const o=e.match(/scroll\s+(vertical|horizontal|down|up|left|right)/i);if(o){const a=o[1].toLowerCase(),i=document.querySelectorAll('[style*="overflow"], [class*="scroll"]');for(const r of i)if(ie(r)){const s=r,c=s.clientHeight*.5;a==="down"||a==="vertical"?s.scrollTop+=c:a==="up"&&(s.scrollTop-=c),await l(150);break}}}async function re(e){const t=document.querySelector(e.selector);if(!(t instanceof HTMLElement)){console.warn("[Replayer] Could not find scroll container:",e.selector);return}e.scrollToReveal&&(console.log("[Replayer] 📜 Scrolling container to reveal element:",{container:e.selector.slice(0,50),targetScroll:e.scrollToReveal}),t.scrollTo({left:e.scrollToReveal.x,top:e.scrollToReveal.y,behavior:"smooth"}),await l(200),await h(200,50))}async function Yt(e,t){const n=t.interactionContext?.widgetContext;if(n?.triggerSelector){const a=document.querySelector(n.triggerSelector);if(a instanceof HTMLElement){console.log("[Replayer] 🔓 Opening widget via trigger:",n.triggerSelector.slice(0,50)),a.click(),await l(300),await h(400,100);return}}const o=e.match(/click(?:ing)?:?\s*([^,\n]+)/i);if(o){const a=o[1].trim(),i=document.querySelector(a);i instanceof HTMLElement&&(console.log("[Replayer] 🔓 Opening via parsed selector:",a.slice(0,50)),i.click(),await l(300),await h(400,100))}}async function Xt(e,t){console.log("[Replayer] ⏳ Waiting for UI stability:",e.slice(0,50)),await h(500,100)}async function Gt(e){if(e.state==="open"||e.state==="expanded"){const t=document.querySelector(e.containerSelector);if((!t||!R(t))&&(console.log("[Replayer] 🔓 Widget not visible, attempting to open via trigger"),e.triggerSelector)){const n=document.querySelector(e.triggerSelector);n instanceof HTMLElement&&(n.click(),await l(300),await h(400,100))}}}async function Wt(e){for(const t of e)!t.isElementVisible&&t.scrollToReveal&&await re(t)}async function Vt(e){const t=z(e.aiDescription||"");if(t.length===0)return null;console.log("[Replayer] 🔍 Looking for dropdown with text:",t);const n=['[role="listbox"]','[role="menu"]','[role="list"]','[data-testid*="suggestion"]','[class*="dropdown"]','[class*="suggestion"]','[class*="autocomplete"]','[class*="listbox"]','[class*="options"]','[id*="location-suggestion"]',".dir-ltr [data-testid]"],o=document.querySelectorAll(n.join(", ")),a=[];for(const r of o)ie(r)&&a.push(r);const i=document.querySelectorAll("*");for(const r of i)ie(r)&&r.querySelectorAll('[role="option"], li, [data-testid*="suggestion"]').length>2&&(a.includes(r)||a.push(r));console.log("[Replayer] Found",a.length,"scrollable containers");for(const r of a){const s=await zt(r,t);if(s)return s}return Pe(t)}function ie(e){if(!(e instanceof HTMLElement))return!1;const t=window.getComputedStyle(e),n=t.overflowY,o=t.overflowX,a=(n==="scroll"||n==="auto")&&e.scrollHeight>e.clientHeight,i=(o==="scroll"||o==="auto")&&e.scrollWidth>e.clientWidth;return a||i}async function zt(e,t){if(!(e instanceof HTMLElement))return null;const n=e.scrollTop,o=10,a=e.clientHeight*.7;console.log("[Replayer] 🔄 Scrolling container to find:",t[0]);let i=Z(e,t);if(i)return i;for(let r=0;r<o;r++){if(e.scrollTop+=a,await l(100),i=Z(e,t),i)return console.log("[Replayer] ✓ Found element after scrolling down",r+1,"times"),i;if(e.scrollTop+e.clientHeight>=e.scrollHeight-10)break}return e.scrollTop=0,await l(100),i=Z(e,t),i||(e.scrollTop=n,null)}function Z(e,t){const n=e.querySelectorAll('[role="option"], li, [data-testid*="suggestion"], div[class*="option"]');for(const o of n){const a=o.textContent?.toLowerCase()||"";for(const i of t)if(a.includes(i.toLowerCase())){const r=o.getBoundingClientRect();if(r.width>0&&r.height>0&&r.top>=0&&r.bottom<=window.innerHeight)return console.log("[Replayer] 🎯 Found matching item:",i),o}}return null}function Pe(e){console.log("[Replayer] 🔍 Searching entire page for:",e);for(const t of e){const n=t.toLowerCase(),o=document.querySelectorAll('button, a, [role="option"], [role="button"], li, [data-testid]');for(const a of o){const i=a.textContent?.trim().toLowerCase()||"",r=a.getAttribute("aria-label")?.toLowerCase()||"";if((i.includes(n)||r.includes(n))&&R(a))return console.log("[Replayer] 🎯 Found matching element on page:",t),a}}return null}async function h(e=500,t=100){return new Promise(n=>{let o=Date.now(),a=!1;const i=new MutationObserver(()=>{o=Date.now()});i.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0});const r=()=>{if(a)return;const c=Date.now()-o,d=Date.now()-s;c>=t||d>=e?(a=!0,i.disconnect(),n()):setTimeout(r,20)},s=Date.now();setTimeout(r,t)})}async function De(e,t=300){const n=Date.now();for(;Date.now()-n<t;){const o=e.getBoundingClientRect();if(o.width>0&&o.height>0){await l(50);const a=e.getBoundingClientRect();if(Math.abs(o.left-a.left)<2&&Math.abs(o.top-a.top)<2&&Math.abs(o.width-a.width)<2&&Math.abs(o.height-a.height)<2)return}await l(50)}}async function Kt(){try{return(await chrome.runtime.sendMessage({type:"GET_AI_STATUS"}))?.enabled??!1}catch{return!1}}async function M(e){if(ae&&(e.screenshot||e.aiDescription)){console.log("[Replayer] Trying AI-first element finding");const t=await ge(e);if(t)if(console.log("[Replayer] AI found element with confidence:",t.confidence),t.confidence>=b.AI_CONFIDENCE_THRESHOLD){const n=X(t.x,t.y,e.tagName);if(n&&R(n)){if(console.log("[Replayer] ✓ AI coordinates matched element:",n.tagName,n.id||n.className?.toString().substring(0,50)),Ht(n,e.aiDescription))return n;{console.log("[Replayer] 🔍 Text mismatch, searching nearby elements...");const o=Ft(t.x,t.y,e.aiDescription);return o?(console.log("[Replayer] ✓ Found better matching element nearby"),o):(console.log("[Replayer] ⚠️ Using element despite text mismatch"),n)}}else{console.log("[Replayer] ⚠️ AI coordinates (",t.x,",",t.y,") did not match a visible element");const o=document.elementFromPoint(t.x,t.y);console.log("[Replayer] Raw element at point:",o?.tagName||"none")}}else{console.log("[Replayer] ⚠️ AI confidence too low:",t.confidence,"< threshold",b.AI_CONFIDENCE_THRESHOLD);const n=Oe(e);if(n==="dropdown"){console.log("[Replayer] 🔄 Attempting to scroll dropdown to find element...");const o=await Vt(e);if(o)return console.log("[Replayer] ✓ Found element after scrolling dropdown"),o}if(n==="date"){console.log("[Replayer] 🔄 Waiting for calendar to appear..."),await h(500,100);const o=await ge(e);if(o&&o.confidence>=b.AI_CONFIDENCE_THRESHOLD){const i=X(o.x,o.y,e.tagName);if(i&&R(i))return console.log("[Replayer] ✓ Found element on retry:",i.tagName),i}const a=z(e.aiDescription||"");if(a.length>0){const i=Pe(a);if(i)return i}}}}return console.log("[Replayer] Falling back to selector-based finding"),Jt(e)}function X(e,t,n){const o=document.elementFromPoint(e,t);if(!o)return null;if(pe(o))return o;let a=o,i=0;for(;a&&i<5;){if(pe(a))return console.log("[Replayer] Found interactive parent:",a.tagName),a;a=a.parentElement,i++}const r=o.querySelectorAll('button, a, input, [role="button"], [role="option"], [role="menuitem"]');for(const s of r){const c=s.getBoundingClientRect();if(e>=c.left&&e<=c.right&&t>=c.top&&t<=c.bottom)return console.log("[Replayer] Found interactive child:",s.tagName),s}return n&&o.tagName.toLowerCase()===n.toLowerCase()||console.log("[Replayer] No interactive element found, using raw element:",o.tagName),o}function pe(e){const t=["BUTTON","A","INPUT","SELECT","TEXTAREA","LABEL"],n=["button","link","checkbox","radio","menuitem","option","tab","listbox"];if(t.includes(e.tagName))return!0;const o=e.getAttribute("role");return!!(o&&n.includes(o)||e instanceof HTMLElement&&window.getComputedStyle(e).cursor==="pointer")}async function ge(e){try{console.log("[Replayer] 🤖 AI element finding started"),console.log("[Replayer] 📸 Capturing current screenshot...");const t=await te(),n=await ne(t,1280,.7);console.log("[Replayer] 📸 Screenshot size:",Math.round(n.length/1024),"KB");let o=e.aiGuidance?.elementIdentification||e.aiGuidance?.description||e.aiDescription||"";if(o)console.log("[Replayer] 🤖 Using description:",o.slice(0,100));else{const r=[];e.tagName&&r.push(e.tagName),e.elementText&&r.push(`with text "${e.elementText}"`),e.elementAttributes?.placeholder&&r.push(`placeholder "${e.elementAttributes.placeholder}"`),e.elementAttributes?.["aria-label"]&&r.push(`labeled "${e.elementAttributes["aria-label"]}"`),e.visualContext?.relativePosition&&r.push(`at ${e.visualContext.relativePosition} of page`),e.interactionContext?.widgetContext&&r.push(`inside a ${e.interactionContext.widgetContext.type}`),o=r.join(" ")||`Element at position (${e.x}, ${e.y})`,console.log("[Replayer] ⚠️ No AI description, using fallback:",o)}const a=e.aiGuidance?{elementIdentification:e.aiGuidance.elementIdentification,widgetType:e.aiGuidance.widgetType,widgetContainer:e.aiGuidance.widgetContainer,preparationSteps:e.aiGuidance.preparationSteps}:void 0;console.log("[Replayer] 🤖 Sending to AI:",{description:o.slice(0,80),hasReferenceScreenshot:!!e.screenshot,hasElementCrop:!!e.elementCrop,originalRect:e.elementRect,hasAIGuidance:!!a,hasInteractionContext:!!e.interactionContext,widgetType:e.interactionContext?.widgetContext?.type});const i=await new Promise((r,s)=>{chrome.runtime.sendMessage({type:"AI_FIND_ELEMENT",request:{currentScreenshot:n,referenceScreenshot:e.screenshot,elementCrop:e.elementCrop,description:o,elementRect:e.elementRect,aiGuidance:a,interactionContext:e.interactionContext}},c=>{chrome.runtime.lastError?s(new Error(chrome.runtime.lastError.message)):r(c)})});if(i.success&&i.result){if(console.log("[Replayer] 🤖 AI Response:",{x:i.result.x,y:i.result.y,confidence:i.result.confidence,reasoning:i.result.reasoning?.slice(0,100),preparationNeeded:i.result.preparationNeeded}),i.result.preparationNeeded&&i.result.confidence<b.AI_CONFIDENCE_THRESHOLD){console.log("[Replayer] 🤖 AI suggests preparation:",i.result.preparationNeeded),await jt(i.result.preparationNeeded,e),console.log("[Replayer] 🤖 Retrying after preparation...");const r=await te(),s=await ne(r,1280,.7),c=await new Promise((d,g)=>{chrome.runtime.sendMessage({type:"AI_FIND_ELEMENT",request:{currentScreenshot:s,referenceScreenshot:e.screenshot,elementCrop:e.elementCrop,description:o,elementRect:e.elementRect,aiGuidance:a,interactionContext:e.interactionContext}},p=>{chrome.runtime.lastError?g(new Error(chrome.runtime.lastError.message)):d(p)})});if(c.success&&c.result)return console.log("[Replayer] 🤖 Retry AI Response:",{x:c.result.x,y:c.result.y,confidence:c.result.confidence}),c.result}return i.result}return console.warn("[Replayer] 🤖 AI returned no result:",i.error),null}catch(t){return console.warn("[Replayer] 🤖 AI element finding failed:",t),null}}async function jt(e,t){console.log("[Replayer] 🔧 Executing AI-suggested preparation:",e.slice(0,100));const n=e.toLowerCase();if(n.includes("date picker")||n.includes("calendar")){const o=document.querySelectorAll('input[type="date"], input[placeholder*="date"], [class*="datepicker"], [data-testid*="date"]');for(const a of o)if(a instanceof HTMLElement&&R(a)){console.log("[Replayer] 🔧 Clicking potential date picker trigger"),a.click(),await l(400),await h(400,100);return}}if((n.includes("dropdown")||n.includes("open"))&&t.interactionContext?.widgetContext?.triggerSelector){const o=document.querySelector(t.interactionContext.widgetContext.triggerSelector);if(o instanceof HTMLElement){console.log("[Replayer] 🔧 Clicking dropdown trigger"),o.click(),await l(300),await h(300,100);return}}if(n.includes("scroll")&&t.interactionContext?.scrollContainers)for(const o of t.interactionContext.scrollContainers)o.isElementVisible||await re(o);await h(400,100)}async function Jt(e){const t=[];if(e.selector&&t.push(()=>{try{return document.querySelector(e.selector)}catch{return null}}),e.selectorFallbacks)for(const a of e.selectorFallbacks)t.push(()=>{try{return document.querySelector(a)}catch{return null}});e.elementText&&e.tagName&&t.push(()=>{const a=document.querySelectorAll(e.tagName);for(const i of a)if(i instanceof HTMLElement&&i.innerText?.trim().includes(e.elementText))return i;return null}),e.elementAttributes&&t.push(()=>{const a=e.elementAttributes;for(const[i,r]of Object.entries(a))try{const s=document.querySelector(`[${i}="${CSS.escape(r)}"]`);if(s)return s}catch{continue}return null});const n=Date.now();let o=50;for(;Date.now()-n<b.ELEMENT_WAIT_TIMEOUT;){for(const a of t){const i=a();if(i&&R(i))return i}await l(o),o=Math.min(o*1.3,300)}for(const a of t){const i=a();if(i)return i}return null}function R(e){if(!(e instanceof HTMLElement))return!0;const t=window.getComputedStyle(e);if(t.display==="none"||t.visibility==="hidden")return!1;const n=e.getBoundingClientRect();return n.width>0&&n.height>0}async function se(e){const t=e.getBoundingClientRect();(t.top<0||t.bottom>window.innerHeight)&&(e.scrollIntoView({behavior:"smooth",block:"center"}),await l(b.SCROLL_SETTLE_TIME))}async function _e(e,t){(Math.abs(window.scrollX-e)>5||Math.abs(window.scrollY-t)>5)&&(window.scrollTo({left:e,top:t,behavior:"smooth"}),await l(b.SCROLL_SETTLE_TIME))}function l(e){return new Promise(t=>setTimeout(t,e))}async function Zt(e){console.log("[Replayer] Click:",e.selector),e.scrollY!==void 0&&await _e(e.scrollX??0,e.scrollY);const t=Oe(e);console.log("[Replayer] Action type:",t),e.interactionContext&&console.log("[Replayer] 🧩 Interaction context:",{widgetType:e.interactionContext.widgetContext?.type,widgetState:e.interactionContext.widgetContext?.state,scrollContainers:e.interactionContext.scrollContainers.length,prepSteps:e.interactionContext.preparationSteps.length,domPath:e.interactionContext.domPath.join(" > ")}),await Ut(e),e.interactionContext?.scrollContainers&&await Wt(e.interactionContext.scrollContainers),e.interactionContext?.widgetContext&&await Gt(e.interactionContext.widgetContext),await h(300,80);const n=await M(e);if(!n){console.warn("[Replayer] Element not found:",e.selector);return}await se(n),await De(n,200);const o=n.getBoundingClientRect(),a=o.left+o.width/2,i=o.top+o.height/2;V(a,i),await l(30),U();const r={bubbles:!0,cancelable:!0,view:window,clientX:a,clientY:i,button:0};n.dispatchEvent(new MouseEvent("mousedown",r)),await l(20),n.dispatchEvent(new MouseEvent("mouseup",r)),n.dispatchEvent(new MouseEvent("click",r)),n instanceof HTMLElement&&n.click();const s=Bt(t);console.log("[Replayer] Waiting",s,"ms for UI to settle"),await l(s),await h(s,80)}async function Qt(e){const t=await M(e);if(!t)return;await se(t);const n=t.getBoundingClientRect(),o=n.left+n.width/2,a=n.top+n.height/2;V(o,a),U(),await l(50),U(),t.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0,cancelable:!0,view:window,clientX:o,clientY:a})),await l(b.CLICK_SETTLE_TIME)}async function en(e){if(!e.key)return;console.log("[Replayer] KeyDown:",e.key);let t=null;if(e.selector&&(t=await M(e)),t||(t=document.activeElement),(!t||t===document.body)&&(console.warn("[Replayer] No target for keydown, trying to find input"),t=document.querySelector("input:focus, textarea:focus")||document.activeElement),!t){console.warn("[Replayer] No target element for key:",e.key);return}const n=new KeyboardEvent("keydown",{key:e.key,code:$e(e.key),keyCode:e.keyCode||fe(e.key),which:e.keyCode||fe(e.key),bubbles:!0,cancelable:!0,composed:!0});if(t.dispatchEvent(n),t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){if(e.key.length===1){const o=t.selectionStart??t.value.length,a=t.selectionEnd??t.value.length,i=t.value.substring(0,o),r=t.value.substring(a);t.value=i+e.key+r,t.selectionStart=t.selectionEnd=o+1,t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e.key}))}else if(e.key==="Backspace"){const o=t.selectionStart??t.value.length,a=t.selectionEnd??t.value.length;o===a&&o>0?(t.value=t.value.substring(0,o-1)+t.value.substring(a),t.selectionStart=t.selectionEnd=o-1):o!==a&&(t.value=t.value.substring(0,o)+t.value.substring(a),t.selectionStart=t.selectionEnd=o),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"deleteContentBackward"}))}else if(e.key==="Delete"){const o=t.selectionStart??0,a=t.selectionEnd??0;o===a&&o<t.value.length?t.value=t.value.substring(0,o)+t.value.substring(a+1):o!==a&&(t.value=t.value.substring(0,o)+t.value.substring(a)),t.selectionStart=t.selectionEnd=o,t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"deleteContentForward"}))}}if(e.key==="Enter"&&t){const o=t.closest("form");if(o){await l(50);const a=o.querySelector('button[type="submit"], input[type="submit"]');a instanceof HTMLElement?a.click():o.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0}))}}await l(b.KEY_DELAY)}async function tn(e){if(!e.key)return;(document.activeElement||document.body).dispatchEvent(new KeyboardEvent("keyup",{key:e.key,code:$e(e.key),keyCode:e.keyCode,bubbles:!0,cancelable:!0})),await l(10)}async function nn(e){console.log("[Replayer] Focus:",e.selector),await h(200,60);const t=await M(e);if(!t){console.warn("[Replayer] Element not found for focus");return}await se(t),await De(t,150);const n=t.getBoundingClientRect();V(n.left+n.width/2,n.top+n.height/2),U(),t.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0})),t.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0})),t.dispatchEvent(new MouseEvent("click",{bubbles:!0})),t.focus(),t.dispatchEvent(new FocusEvent("focus",{bubbles:!1})),t.dispatchEvent(new FocusEvent("focusin",{bubbles:!0})),(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&t.select(),await l(100),await h(200,60)}async function on(e){console.log("[Replayer] Blur:",e.selector);const t=e.selector?await M(e):document.activeElement;t instanceof HTMLElement&&(t.dispatchEvent(new FocusEvent("blur",{bubbles:!1})),t.dispatchEvent(new FocusEvent("focusout",{bubbles:!0})),t.blur()),await l(30)}async function an(e){console.log("[Replayer] Change:",e.selector);const t=await M(e);t&&(e.value!==void 0&&(t.value=e.value),t.dispatchEvent(new Event("change",{bubbles:!0})),await l(30))}async function rn(e){await _e(e.scrollX??0,e.scrollY??0)}async function sn(e){console.log("[Replayer] Submit:",e.selector);const t=await M(e);if(!t)return;document.activeElement instanceof HTMLElement&&(document.activeElement.blur(),await l(50));const n=t.querySelector('button[type="submit"], input[type="submit"], button:not([type])');n instanceof HTMLElement?n.click():t.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0})),await l(b.CLICK_SETTLE_TIME)}async function cn(e){e.url&&e.url!==window.location.href&&(console.log("[Replayer] Navigate:",e.url),window.location.href=e.url,await l(1e3))}function $e(e){const t={Enter:"Enter",Tab:"Tab",Escape:"Escape",Backspace:"Backspace",Delete:"Delete",ArrowUp:"ArrowUp",ArrowDown:"ArrowDown",ArrowLeft:"ArrowLeft",ArrowRight:"ArrowRight"," ":"Space"};if(t[e])return t[e];if(e.length===1){if(e>="a"&&e<="z")return`Key${e.toUpperCase()}`;if(e>="A"&&e<="Z")return`Key${e}`;if(e>="0"&&e<="9")return`Digit${e}`}return e}function fe(e){if(e.length===1){const n=e.toUpperCase().charCodeAt(0);if(n>=65&&n<=90||n>=48&&n<=57)return n}return{Enter:13,Tab:9,Escape:27,Backspace:8,Delete:46,ArrowUp:38,ArrowDown:40,ArrowLeft:37,ArrowRight:39," ":32}[e]||0}async function ln(e){if(!Y)switch(e.x!==void 0&&e.y!==void 0&&V(e.x,e.y),e.type){case"click":await Zt(e);break;case"dblclick":await Qt(e);break;case"keydown":await en(e);break;case"keyup":await tn(e);break;case"focus":await nn(e);break;case"blur":await on(e);break;case"change":await an(e);break;case"scroll":await rn(e);break;case"submit":await sn(e);break;case"navigate":await cn(e);break}}async function He(e,t){console.log("[Replayer] Starting:",e.name),console.log("[Replayer] Events:",e.events?.length),B=!0,Y=!1,ae=await Kt(),console.log("[Replayer] AI enabled:",ae);const n=e.events;if(!n||n.length===0)return{success:!1,error:"No events to replay",eventsCompleted:0};Qe(),console.log(`[Replayer] Waiting ${b.INITIAL_DELAY}ms...`),await l(b.INITIAL_DELAY);let o=0;try{for(let a=0;a<n.length;a++){if(Y)return{success:!1,error:"Stopped by user",eventsCompleted:o};const i=n[a],r=n[a-1];if(r){const s=i.timestamp-r.timestamp,c=Math.min(Math.max(s,b.MIN_EVENT_GAP),3e3);await l(c)}console.log(`[Replayer] ${a+1}/${n.length}: ${i.type}${i.key?` (${i.key})`:""}`),await ln(i),o=a+1,t?.(o,n.length)}return console.log("[Replayer] Complete!"),await l(300),ee(),B=!1,{success:!0,eventsCompleted:o}}catch(a){return console.error("[Replayer] Error:",a),ee(),B=!1,{success:!1,error:a instanceof Error?a.message:"Unknown error",eventsCompleted:o}}}function un(){Y=!0,B=!1,ee()}console.log("[Openmation] Content script loaded on:",window.location.href);$t();pn();chrome.runtime.onMessage.addListener((e,t,n)=>(console.log("[Openmation] Content received:",e.type),dn(e).then(n).catch(o=>{console.error("[Openmation] Error:",o),n({success:!1,error:o.message})}),!0));window.addEventListener("message",e=>{if(e.source===window&&!(!e.data||!e.data.type))switch(e.data.type){case"OPENMATION_START_RECORDING":chrome.runtime.sendMessage({type:"START_RECORDING_FROM_PANEL"});break;case"OPENMATION_CHECK_EXTENSION":console.log("[Openmation] Extension check received, responding..."),window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*");break;case"OPENMATION_RUN_SHARED":console.log("[Openmation] Received SIMPLEST_RUN_SHARED:",e.data.automationId),e.data.automationId&&gn(e.data.automationId);break}});setTimeout(()=>{window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*")},100);async function dn(e){switch(e.type){case"PING":return{success:!0,loaded:!0};case"INJECT_PANEL":return console.log("[Openmation] Creating panel..."),Ue(),{success:!0};case"REMOVE_PANEL":return _(),{success:!0};case"START_RECORDING":{const t=e.sessionId||crypto.randomUUID();await de(t),J({mode:"recording",eventCount:0,duration:0,startTime:Date.now()});const n=document.getElementById("openmation-panel");if(n){const o=n.querySelector(".sa-start-view"),a=n.querySelector(".sa-recording-view");o&&(o.style.display="none"),a&&(a.style.display="block")}return{success:!0,sessionId:t}}case"RESTORE_RECORDING_STATE":{const{sessionId:t,eventCount:n,duration:o,isPaused:a}=e;return await de(t),qe(n,o,a),{success:!0}}case"PAUSE_RECORDING":return Mt(),J({mode:"paused"}),{success:!0};case"RESUME_RECORDING":return Ot(),J({mode:"recording"}),{success:!0};case"STOP_RECORDING":return{success:!0,...Pt()};case"GET_RECORDING_STATE":return{success:!0,state:Dt()};case"RUN_AUTOMATION":{const t=e.automation;return t?(He(t,(n,o)=>{chrome.runtime.sendMessage({type:"AUTOMATION_PROGRESS",runId:t.id,eventsCompleted:n,totalEvents:o,status:"running"}).catch(()=>{})}).then(n=>{chrome.runtime.sendMessage({type:"AUTOMATION_COMPLETE",runId:t.id,status:n.success?"success":"failed",error:n.error,eventsCompleted:n.eventsCompleted}).catch(()=>{})}),{success:!0,message:"Replay started"}):{success:!1,error:"No automation provided"}}case"STOP_AUTOMATION":return un(),{success:!0};default:return{success:!1,error:"Unknown message type"}}}function pn(){const t=window.location.href.match(/\/run\/([a-zA-Z0-9_-]+)$/);if(t){const n=t[1];console.log("[Openmation] Detected shared automation page:",n),setTimeout(()=>{window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*")},100)}}async function gn(e){console.log("[Openmation] Running shared automation:",e);try{console.log("[Openmation] Fetching from:",`${Q}/api/automations/${e}`);const t=await fetch(`${Q}/api/automations/${e}`),n=await t.json();if(console.log("[Openmation] API response:",n),!t.ok||!n.success){console.error("[Openmation] Failed to fetch automation:",n.error),alert("Failed to load automation: "+(n.error||"Unknown error"));return}const o=n.automation;console.log("[Openmation] Automation loaded:",o.name,"startUrl:",o.startUrl),o.startUrl&&!window.location.href.startsWith(o.startUrl.split("?")[0])?(console.log("[Openmation] Storing automation and redirecting to:",o.startUrl),sessionStorage.setItem("openmation_pending_automation",JSON.stringify(o)),window.location.href=o.startUrl):(console.log("[Openmation] Already on target page, running immediately"),Fe(o))}catch(t){console.error("[Openmation] Error running shared automation:",t),alert("Failed to run automation. Please try again.")}}function Fe(e){if(console.log("[Openmation] Executing automation:",e.name),console.log("[Openmation] Events count:",e.events?.length),console.log("[Openmation] First event:",e.events?.[0]),!e.events||e.events.length===0){console.error("[Openmation] No events in automation!");return}He(e,(t,n)=>{console.log(`[Openmation] Progress: ${t}/${n}`)}).then(t=>{t.success?console.log("[Openmation] Automation completed successfully"):console.error("[Openmation] Automation failed:",t.error)}).catch(t=>{console.error("[Openmation] Replay error:",t)})}async function fn(){const e=window.location.hostname;if((e==="openmation.dev"||e==="www.openmation.dev"||e==="api.openmation.dev")&&window.location.pathname.startsWith("/run/")){console.log("[Openmation] On run page, skipping pending check");return}const o=window.location.hash.match(/openmation_run=([a-zA-Z0-9_-]+)/);if(o){const a=o[1];console.log("[Openmation] Found automation ID in URL:",a),history.replaceState(null,"",window.location.pathname+window.location.search);try{console.log("[Openmation] Fetching automation from API...");const r=await(await fetch(`${Q}/api/automations/${a}`)).json();r.success&&r.automation?(console.log("[Openmation] Fetched automation, executing:",r.automation.name),setTimeout(()=>{Fe(r.automation)},1500)):(console.error("[Openmation] Failed to fetch automation:",r.error),alert("Failed to load automation. It may have expired."))}catch(i){console.error("[Openmation] Error fetching automation:",i),alert("Failed to connect to automation server.")}return}}setTimeout(fn,500);
