import{g as ye,d as be}from"./utils-CJ54F2El.js";const y="openmation-panel",b="openmation-cursor";let r={mode:"ready",eventCount:0,duration:0,startTime:0},S=null;function ve(){C();const e=document.createElement("div");e.id=y,e.innerHTML=_e();const t=document.createElement("style");return t.id=`${y}-styles`,t.textContent=Ne(),document.head.appendChild(t),document.body.appendChild(e),ke(e),Ie(e),e}function C(){const e=document.getElementById(y);e&&e.remove();const t=document.getElementById(`${y}-styles`);t&&t.remove(),T()}function P(e){r={...r,...e},e.mode==="recording"&&!S?A():(e.mode==="paused"||e.mode==="ready"||e.mode==="saving")&&T(),R()}function we(e,t,n){r={mode:n?"paused":"recording",eventCount:e,duration:t,startTime:Date.now()-t},n||A(),R(),G()}function A(){T(),r.startTime=Date.now()-r.duration,S=setInterval(()=>{r.mode==="recording"&&(r.duration=Date.now()-r.startTime,Ee())},100)}function T(){S&&(clearInterval(S),S=null)}function Ee(){const e=document.querySelector(".sa-duration");e&&(e.textContent=Y(r.duration))}function R(){const e=document.getElementById(y);if(!e)return;const t=e.querySelector(".sa-status-dot"),n=e.querySelector(".sa-status-text");if(t&&n)switch(t.className="sa-status-dot",r.mode){case"recording":t.classList.add("sa-recording"),n.textContent="Recording";break;case"paused":t.classList.add("sa-paused"),n.textContent="Paused";break;case"saving":n.textContent="Save Recording";break;default:n.textContent="Ready"}const o=e.querySelector(".sa-event-count"),a=e.querySelector(".sa-duration");o&&(o.textContent=`${r.eventCount} action${r.eventCount!==1?"s":""}`),a&&(a.textContent=Y(r.duration));const s=e.querySelector(".sa-pause-icon");s&&(s.innerHTML=r.mode==="paused"?Ae():V())}function G(){const e=document.getElementById(y);if(!e)return;const t=e.querySelector(".sa-start-view"),n=e.querySelector(".sa-recording-view"),o=e.querySelector(".sa-save-view");t&&(t.style.display="none"),n&&(n.style.display="block"),o&&(o.style.display="none")}function xe(){const e=document.getElementById(y);if(!e)return;const t=e.querySelector(".sa-start-view"),n=e.querySelector(".sa-recording-view"),o=e.querySelector(".sa-save-view");t&&(t.style.display="none"),n&&(n.style.display="none"),o&&(o.style.display="block");const a=e.querySelector(".sa-name-input");a&&setTimeout(()=>a.focus(),100)}function Y(e){const t=Math.floor(e/1e3),n=Math.floor(t/60),o=t%60;return`${n.toString().padStart(2,"0")}:${o.toString().padStart(2,"0")}`}function ke(e){e.querySelector(".sa-start-btn")?.addEventListener("click",Te),e.querySelector(".sa-pause-btn")?.addEventListener("click",Se),e.querySelector(".sa-stop-btn")?.addEventListener("click",Ce),e.querySelector(".sa-save-btn")?.addEventListener("click",X),e.querySelector(".sa-discard-btn")?.addEventListener("click",Re),e.querySelector(".sa-close-btn")?.addEventListener("click",Le),e.querySelector(".sa-name-input")?.addEventListener("keydown",t=>{t.key==="Enter"&&X()})}async function Te(){chrome.runtime.sendMessage({type:"START_RECORDING_FROM_PANEL"}),r.mode="recording",r.eventCount=0,r.duration=0,A(),R(),G()}async function Se(){r.mode==="paused"?(chrome.runtime.sendMessage({type:"RESUME_RECORDING"}),r.mode="recording",A()):(chrome.runtime.sendMessage({type:"PAUSE_RECORDING"}),r.mode="paused",T()),R()}async function Ce(){T(),r.mode="saving",R(),xe()}async function X(){const e=document.getElementById(y),n=e?.querySelector(".sa-name-input")?.value.trim()||`Recording ${new Date().toLocaleString()}`,o=e?.querySelector(".sa-save-btn");o&&(o.disabled=!0,o.textContent="Saving..."),chrome.runtime.sendMessage({type:"STOP_RECORDING_WITH_NAME",name:n},a=>{a?.shareUrl&&navigator.clipboard.writeText(a.shareUrl).then(()=>{H(a.shareUrl)}).catch(()=>{H(a.shareUrl,!1)}),setTimeout(()=>{C()},3e3)})}function H(e,t=!0){const n=document.getElementById("openmation-success-toast");n&&n.remove();const o=document.createElement("div");o.id="openmation-success-toast",o.innerHTML=`
    <div class="om-toast-content">
      <div class="om-toast-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M20 6L9 17l-5-5"/>
        </svg>
      </div>
      <div class="om-toast-text">
        <div class="om-toast-title">Automation saved! ${t?"✓ Link copied":""}</div>
        <div class="om-toast-url">${e}</div>
      </div>
      <button class="om-toast-copy" onclick="navigator.clipboard.writeText('${e}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
        </svg>
      </button>
    </div>
  `;const a=document.createElement("style");a.id="openmation-success-toast-styles",a.textContent=`
    #openmation-success-toast {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483647;
      animation: om-toast-enter 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes om-toast-enter {
      from {
        opacity: 0;
        transform: translateX(-50%) translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
    }
    
    .om-toast-content {
      display: flex;
      align-items: center;
      gap: 12px;
      background: #ffffff;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 14px;
      padding: 14px 18px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.06);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    .om-toast-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.1);
      color: #10B981;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .om-toast-text {
      flex: 1;
      min-width: 0;
    }
    
    .om-toast-title {
      font-size: 14px;
      font-weight: 600;
      color: #1a1a1a;
      margin-bottom: 2px;
    }
    
    .om-toast-url {
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
      font-family: monospace;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 300px;
    }
    
    .om-toast-copy {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.6);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
      flex-shrink: 0;
    }
    
    .om-toast-copy:hover {
      background: rgba(0, 0, 0, 0.08);
      color: rgba(0, 0, 0, 0.8);
    }
  `,document.head.appendChild(a),document.body.appendChild(o),setTimeout(()=>{o.remove(),a.remove()},5e3)}function Re(){chrome.runtime.sendMessage({type:"STOP_RECORDING"}),C()}function Le(){if(r.mode==="recording"||r.mode==="paused"){if(!confirm("Stop recording and discard?"))return;chrome.runtime.sendMessage({type:"STOP_RECORDING"})}C()}function Ie(e){const t=e.querySelector(".sa-panel-header");if(!t)return;let n=!1,o=0,a=0,s=0,u=0;t.addEventListener("mousedown",i=>{if(i.target.closest("button")||i.target.closest("input"))return;n=!0,o=i.clientX,a=i.clientY;const k=e.getBoundingClientRect();s=k.left,u=k.top,t.style.cursor="grabbing",i.preventDefault()}),document.addEventListener("mousemove",i=>{if(!n)return;const k=i.clientX-o,me=i.clientY-a;let N=s+k,D=u+me;const ge=window.innerWidth-e.offsetWidth-10,he=window.innerHeight-e.offsetHeight-10;N=Math.max(10,Math.min(N,ge)),D=Math.max(10,Math.min(D,he)),e.style.left=`${N}px`,e.style.top=`${D}px`,e.style.right="auto"}),document.addEventListener("mouseup",()=>{n&&(n=!1,t.style.cursor="grab")})}function Me(){r.eventCount++;const e=document.querySelector(".sa-event-count");e&&(e.textContent=`${r.eventCount} action${r.eventCount!==1?"s":""}`,e.style.transform="scale(1.05)",setTimeout(()=>{e.style.transform="scale(1)"},100))}function Oe(){const e=document.getElementById(b);e&&e.remove();const t=document.createElement("div");t.id=b,t.innerHTML=`
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M5.5 3.5L20 11.5L12 14L9 21L5.5 3.5Z" fill="#3B82F6" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>
    </svg>
    <div class="sa-cursor-ripple"></div>
  `;const n=document.createElement("style");return n.id=`${b}-styles`,n.textContent=`
    #${b} {
      position: fixed;
      pointer-events: none;
      z-index: 2147483646;
      transform: translate(-3px, -3px);
      transition: left 16ms linear, top 16ms linear;
      filter: drop-shadow(0 2px 8px rgba(59, 130, 246, 0.3));
    }
    .sa-cursor-ripple {
      position: absolute;
      top: 10px;
      left: 10px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(59, 130, 246, 0.4);
      transform: translate(-50%, -50%) scale(0);
      opacity: 0;
    }
    .sa-cursor-ripple.active {
      animation: sa-ripple 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    @keyframes sa-ripple {
      0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(2.5); opacity: 0; }
    }
  `,document.head.appendChild(n),document.body.appendChild(t),t}function _(e,t){const n=document.getElementById(b);n&&(n.style.left=`${e}px`,n.style.top=`${t}px`)}function M(){const e=document.querySelector(`#${b} .sa-cursor-ripple`);e&&(e.classList.remove("active"),e.offsetWidth,e.classList.add("active"))}function B(){document.getElementById(b)?.remove(),document.getElementById(`${b}-styles`)?.remove()}function Ae(){return'<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"/></svg>'}function V(){return'<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="4" width="5" height="16" rx="1"/><rect x="14" y="4" width="5" height="16" rx="1"/></svg>'}function _e(){return`
    <div class="sa-panel-inner">
      <div class="sa-panel-header">
        <div class="sa-brand">
          <div class="sa-logo">
            <img src="${chrome.runtime.getURL("icons/icon48.png")}" alt="Openmation" width="24" height="24" style="object-fit: contain;" />
          </div>
          <span class="sa-title">Openmation</span>
        </div>
        <button class="sa-close-btn" title="Close">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
      
      <div class="sa-panel-body">
        <!-- Ready State -->
        <div class="sa-start-view">
          <button class="sa-start-btn">
            <div class="sa-start-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <circle cx="12" cy="12" r="8"/>
              </svg>
            </div>
            <span>Start Recording</span>
          </button>
          <p class="sa-hint">Click to begin capturing your actions</p>
        </div>
        
        <!-- Recording State -->
        <div class="sa-recording-view" style="display: none;">
          <div class="sa-status-bar">
            <div class="sa-status">
              <div class="sa-status-dot sa-recording"></div>
              <span class="sa-status-text">Recording</span>
            </div>
            <div class="sa-stats">
              <span class="sa-event-count">0 actions</span>
              <span class="sa-divider">·</span>
              <span class="sa-duration">00:00</span>
            </div>
          </div>
          
          <div class="sa-controls">
            <button class="sa-pause-btn" title="Pause">
              <span class="sa-pause-icon">${V()}</span>
            </button>
            <button class="sa-stop-btn">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="6" width="12" height="12" rx="2"/>
              </svg>
              <span>Finish</span>
            </button>
          </div>
        </div>
        
        <!-- Save State -->
        <div class="sa-save-view" style="display: none;">
          <div class="sa-save-header">
            <div class="sa-save-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 6L9 17l-5-5"/>
              </svg>
            </div>
            <div class="sa-save-info">
              <span class="sa-event-count-final">${r.eventCount} actions</span>
              <span class="sa-divider">·</span>
              <span class="sa-duration-final">${Y(r.duration)}</span>
            </div>
          </div>
          
          <input type="text" class="sa-name-input" placeholder="Name your automation..." autocomplete="off" spellcheck="false"/>
          
          <div class="sa-save-actions">
            <button class="sa-discard-btn">Discard</button>
            <button class="sa-save-btn">Save</button>
          </div>
        </div>
      </div>
    </div>
  `}function Ne(){return`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
    
    #${y} {
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
      font-size: 13px;
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      animation: sa-panel-enter 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes sa-panel-enter {
      from {
        opacity: 0;
        transform: translateY(-8px) scale(0.96);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }
    
    .sa-panel-inner {
      background: #ffffff;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 16px;
      box-shadow: 
        0 0 0 1px rgba(0, 0, 0, 0.04),
        0 8px 40px rgba(0, 0, 0, 0.12),
        0 2px 8px rgba(0, 0, 0, 0.06);
      overflow: hidden;
      min-width: 260px;
      color: #1a1a1a;
    }
    
    /* Header */
    .sa-panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 14px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      cursor: grab;
      user-select: none;
    }
    
    .sa-brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .sa-logo {
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .sa-logo img {
      width: 24px;
      height: 24px;
      object-fit: contain;
    }
    
    .sa-title {
      font-weight: 600;
      font-size: 14px;
      background: linear-gradient(135deg, #06B6D4 0%, #3B82F6 50%, #2563EB 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      letter-spacing: -0.02em;
    }
    
    .sa-close-btn {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      border: none;
      background: transparent;
      color: rgba(0, 0, 0, 0.4);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    
    .sa-close-btn:hover {
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.7);
    }
    
    /* Panel Body */
    .sa-panel-body {
      padding: 14px;
    }
    
    /* Start View */
    .sa-start-view {
      text-align: center;
    }
    
    .sa-start-btn {
      width: 100%;
      height: 48px;
      border-radius: 12px;
      border: 1.5px solid rgba(0, 0, 0, 0.1);
      background: #ffffff;
      color: #1a1a1a;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.2s ease;
    }
    
    .sa-start-btn:hover {
      border-color: rgba(59, 130, 246, 0.3);
      background: rgba(59, 130, 246, 0.04);
    }
    
    .sa-start-icon {
      color: #EF4444;
    }
    
    .sa-hint {
      margin: 12px 0 0 0;
      font-size: 11px;
      color: rgba(0, 0, 0, 0.45);
    }
    
    /* Recording View */
    .sa-status-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }
    
    .sa-status {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .sa-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: rgba(0, 0, 0, 0.2);
    }
    
    .sa-status-dot.sa-recording {
      background: #EF4444;
      animation: sa-pulse 1.2s ease-in-out infinite;
    }
    
    .sa-status-dot.sa-paused {
      background: #F59E0B;
    }
    
    @keyframes sa-pulse {
      0%, 100% { 
        opacity: 1;
        box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
      }
      50% { 
        opacity: 0.8;
        box-shadow: 0 0 0 5px rgba(239, 68, 68, 0);
      }
    }
    
    .sa-status-text {
      font-size: 12px;
      font-weight: 500;
      color: #1a1a1a;
    }
    
    .sa-stats {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
      font-variant-numeric: tabular-nums;
    }
    
    .sa-divider {
      color: rgba(0, 0, 0, 0.2);
    }
    
    .sa-event-count {
      transition: transform 0.1s ease;
    }
    
    /* Controls */
    .sa-controls {
      display: flex;
      gap: 8px;
    }
    
    .sa-pause-btn {
      width: 44px;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.7);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    
    .sa-pause-btn:hover {
      background: rgba(0, 0, 0, 0.08);
    }
    
    .sa-stop-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: #1a1a1a;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    
    .sa-stop-btn:hover {
      background: #2a2a2a;
    }
    
    /* Save View */
    .sa-save-view {
      animation: sa-fade-in 0.2s ease;
    }
    
    @keyframes sa-fade-in {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    .sa-save-header {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 12px;
    }
    
    .sa-save-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.1);
      color: #10B981;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .sa-save-info {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: rgba(0, 0, 0, 0.5);
    }
    
    .sa-name-input {
      width: 100%;
      height: 44px;
      padding: 0 14px;
      border-radius: 10px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      background: #ffffff;
      color: #1a1a1a;
      font-size: 13px;
      font-family: inherit;
      outline: none;
      transition: all 0.15s ease;
      box-sizing: border-box;
    }
    
    .sa-name-input::placeholder {
      color: rgba(0, 0, 0, 0.35);
    }
    
    .sa-name-input:focus {
      border-color: rgba(59, 130, 246, 0.5);
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    .sa-save-actions {
      display: flex;
      gap: 8px;
      margin-top: 12px;
    }
    
    .sa-discard-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.6);
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    
    .sa-discard-btn:hover {
      background: rgba(0, 0, 0, 0.08);
      color: rgba(0, 0, 0, 0.8);
    }
    
    .sa-save-btn {
      flex: 1;
      height: 40px;
      border-radius: 10px;
      border: none;
      background: #1a1a1a;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    
    .sa-save-btn:hover {
      background: #2a2a2a;
    }
    
    .sa-save-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `}let d=!1,l=!1,h=[],E=[],w=[],v=0,L="";const De=50;let q=0;function Pe(e){const t=be(e),n=[],o={};if(e.id&&(n.push(`#${CSS.escape(e.id)}`),o.id=e.id),e.className&&typeof e.className=="string"){const u=e.className.trim().split(/\s+/).filter(i=>i&&!i.startsWith("sa-"));u.length>0&&n.push(`${e.tagName.toLowerCase()}.${u.map(i=>CSS.escape(i)).join(".")}`)}const a=e;a.getAttribute&&["name","data-testid","data-id","aria-label","placeholder","type","role"].forEach(u=>{const i=a.getAttribute(u);i&&(n.push(`${e.tagName.toLowerCase()}[${u}="${CSS.escape(i)}"]`),o[u]=i)});let s;if(e instanceof HTMLElement&&(e.tagName==="BUTTON"||e.tagName==="A")){const u=e.innerText?.trim().slice(0,50);u&&(s=u)}return{primary:t,fallbacks:n,textContent:s,attributes:o}}function Be(e){const t=e.getBoundingClientRect();return{viewportX:t.left+t.width/2,viewportY:t.top+t.height/2,pageX:t.left+window.scrollX+t.width/2,pageY:t.top+window.scrollY+t.height/2,rect:{top:t.top,left:t.left,width:t.width,height:t.height}}}function p(e,t,n={}){const o={id:ye(),type:e,timestamp:Date.now()-v,scrollX:window.scrollX,scrollY:window.scrollY,...n};if(t){const a=Pe(t);o.selector=a.primary,o.selectorFallbacks=a.fallbacks,o.elementText=a.textContent,o.elementAttributes=a.attributes,o.tagName=t.tagName.toLowerCase();const s=Be(t);o.elementRect=s.rect,o.pageX=s.pageX,o.pageY=s.pageY,t instanceof HTMLElement&&t.innerText&&(o.innerText=t.innerText.slice(0,100))}return w.length>0&&(o.mousePath=[...w],w=[]),o}function j(e){if(!d||l||m(e.target))return;const t=p("click",e.target,{x:e.clientX,y:e.clientY,pageX:e.pageX,pageY:e.pageY});f(t),$e(e.clientX,e.clientY)}function W(e){if(!d||l||m(e.target))return;const t=p("dblclick",e.target,{x:e.clientX,y:e.clientY,pageX:e.pageX,pageY:e.pageY});f(t)}function J(e){if(!d||l||m(e.target))return;const t=p("mousedown",e.target,{x:e.clientX,y:e.clientY});f(t)}function Z(e){if(!d||l||m(e.target))return;const t=p("mouseup",e.target,{x:e.clientX,y:e.clientY});f(t)}function Q(e){if(!d||l)return;const t=Date.now();if(t-q<De)return;q=t;const n={x:e.clientX,y:e.clientY,timestamp:t-v};E.push(n),w.push(n),w.length>30&&w.shift()}function ee(e){if(!d||l||m(e.target))return;const t=e.target,n=t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement;if(n||["Enter","Tab","Escape","Backspace","Delete","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Home","End","PageUp","PageDown"].includes(e.key)||e.ctrlKey||e.metaKey||e.altKey){const s=p("keydown",t,{key:e.key,keyCode:e.keyCode,value:n?t.value:void 0});f(s)}}function te(e){if(!d||l||m(e.target))return;if(["Enter","Tab","Escape"].includes(e.key)){const n=p("keyup",e.target,{key:e.key,keyCode:e.keyCode});f(n)}}function ne(e){if(!d||l)return;const t=e.target;if(!t||m(t))return;const n=p("input",t,{value:t.value});n.isCheckpoint=!0,f(n)}function oe(e){if(!d||l)return;const t=e.target;if(!t||m(t))return;const n=p("change",t,{value:t.value});f(n)}function ae(){if(!d||l)return;const e=h[h.length-1],t=Date.now()-v;if(e?.type==="scroll"&&t-e.timestamp<100){e.scrollX=window.scrollX,e.scrollY=window.scrollY,e.timestamp=t;return}const n=p("scroll",null,{scrollX:window.scrollX,scrollY:window.scrollY});f(n)}function se(e){if(!d||l||m(e.target))return;const t=e.target;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement){const n=p("focus",t);f(n)}}function re(e){if(!d||l||m(e.target))return;const t=e.target;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement){const n=p("blur",t,{value:t.value});f(n)}}function ie(e){if(!d||l||m(e.target))return;const t=p("submit",e.target);f(t)}function ce(){if(!d)return;const e=p("navigate",null,{url:window.location.href});f(e),Ue()}function m(e){return e?!!(e.closest("#openmation-panel")||e.closest("#openmation-cursor")):!1}function f(e){h.push(e),e.isCheckpoint||Me(),chrome.runtime.sendMessage({type:"EVENT_RECORDED",event:e}).catch(()=>{})}function $e(e,t){const n=document.createElement("div");n.style.cssText=`
    position: fixed;
    left: ${e}px;
    top: ${t}px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: rgba(99, 102, 241, 0.3);
    transform: translate(-50%, -50%) scale(0);
    pointer-events: none;
    z-index: 2147483645;
    animation: sa-click-ripple 0.4s ease-out forwards;
  `;const o=document.createElement("style");o.textContent=`
    @keyframes sa-click-ripple {
      0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(3); opacity: 0; }
    }
  `,document.head.appendChild(o),document.body.appendChild(n),setTimeout(()=>{n.remove(),o.remove()},400)}function Ue(){const e={isRecording:d,isPaused:l,events:h,mouseMovements:E,startUrl:window.location.href,startTime:v,sessionId:L};try{localStorage.setItem("openmation_recording_state",JSON.stringify(e))}catch{}}function le(){try{const e=localStorage.getItem("openmation_recording_state");if(!e)return!1;const t=JSON.parse(e);if(t.sessionId&&t.isRecording)return h=t.events||[],E=t.mouseMovements||[],v=t.startTime,L=t.sessionId,d=!0,l=t.isPaused,localStorage.removeItem("openmation_recording_state"),!0}catch{}return!1}function z(e){if(le()){console.log("[Openmation] Resumed recording from previous page"),$();return}d=!0,l=!1,h=[],E=[],w=[],v=Date.now(),L=e,$(),console.log("[Openmation] Recording started")}function Ye(){l=!0,console.log("[Openmation] Recording paused")}function Fe(){l=!1,console.log("[Openmation] Recording resumed")}function Xe(){d=!1,l=!1,qe(),localStorage.removeItem("openmation_recording_state");const t={events:h.filter(n=>!n.isCheckpoint),mouseMovements:[...E],startUrl:window.location.href,duration:Date.now()-v};return h=[],E=[],console.log("[Openmation] Recording stopped:",t.events.length,"events"),t}function He(){return{isRecording:d,isPaused:l,events:h,mouseMovements:E,startUrl:window.location.href,startTime:v,sessionId:L}}function $(){document.addEventListener("click",j,!0),document.addEventListener("dblclick",W,!0),document.addEventListener("mousedown",J,!0),document.addEventListener("mouseup",Z,!0),document.addEventListener("mousemove",Q,!0),document.addEventListener("input",ne,!0),document.addEventListener("change",oe,!0),document.addEventListener("keydown",ee,!0),document.addEventListener("keyup",te,!0),document.addEventListener("focus",se,!0),document.addEventListener("blur",re,!0),document.addEventListener("submit",ie,!0),window.addEventListener("scroll",ae,!0),window.addEventListener("beforeunload",ce)}function qe(){document.removeEventListener("click",j,!0),document.removeEventListener("dblclick",W,!0),document.removeEventListener("mousedown",J,!0),document.removeEventListener("mouseup",Z,!0),document.removeEventListener("mousemove",Q,!0),document.removeEventListener("input",ne,!0),document.removeEventListener("change",oe,!0),document.removeEventListener("keydown",ee,!0),document.removeEventListener("keyup",te,!0),document.removeEventListener("focus",se,!0),document.removeEventListener("blur",re,!0),document.removeEventListener("submit",ie,!0),window.removeEventListener("scroll",ae,!0),window.removeEventListener("beforeunload",ce)}function ze(){le()&&($(),chrome.runtime.sendMessage({type:"RECORDING_RESUMED_ON_PAGE",sessionId:L,eventCount:h.length}).catch(()=>{}))}let I=!1,O=!1;const g={INITIAL_DELAY:2e3,ELEMENT_WAIT_TIMEOUT:1e4,SCROLL_SETTLE_TIME:200,CLICK_SETTLE_TIME:100,KEY_DELAY:30,MIN_EVENT_GAP:20};async function x(e){const t=[];if(e.selector&&t.push(()=>{try{return document.querySelector(e.selector)}catch{return null}}),e.selectorFallbacks)for(const a of e.selectorFallbacks)t.push(()=>{try{return document.querySelector(a)}catch{return null}});e.elementText&&e.tagName&&t.push(()=>{const a=document.querySelectorAll(e.tagName);for(const s of a)if(s instanceof HTMLElement&&s.innerText?.trim().includes(e.elementText))return s;return null}),e.elementAttributes&&t.push(()=>{const a=e.elementAttributes;for(const[s,u]of Object.entries(a))try{const i=document.querySelector(`[${s}="${CSS.escape(u)}"]`);if(i)return i}catch{continue}return null});const n=Date.now();let o=50;for(;Date.now()-n<g.ELEMENT_WAIT_TIMEOUT;){for(const a of t){const s=a();if(s&&Ke(s))return s}await c(o),o=Math.min(o*1.3,300)}for(const a of t){const s=a();if(s)return s}return null}function Ke(e){if(!(e instanceof HTMLElement))return!0;const t=window.getComputedStyle(e);if(t.display==="none"||t.visibility==="hidden")return!1;const n=e.getBoundingClientRect();return n.width>0&&n.height>0}async function F(e){const t=e.getBoundingClientRect();(t.top<0||t.bottom>window.innerHeight)&&(e.scrollIntoView({behavior:"smooth",block:"center"}),await c(g.SCROLL_SETTLE_TIME))}async function ue(e,t){(Math.abs(window.scrollX-e)>5||Math.abs(window.scrollY-t)>5)&&(window.scrollTo({left:e,top:t,behavior:"smooth"}),await c(g.SCROLL_SETTLE_TIME))}function c(e){return new Promise(t=>setTimeout(t,e))}async function Ge(e){console.log("[Replayer] Click:",e.selector),e.scrollY!==void 0&&await ue(e.scrollX??0,e.scrollY);const t=await x(e);if(!t){console.warn("[Replayer] Element not found:",e.selector);return}await F(t);const n=t.getBoundingClientRect(),o=n.left+n.width/2,a=n.top+n.height/2;_(o,a),await c(30),M();const s={bubbles:!0,cancelable:!0,view:window,clientX:o,clientY:a,button:0};t.dispatchEvent(new MouseEvent("mousedown",s)),await c(20),t.dispatchEvent(new MouseEvent("mouseup",s)),t.dispatchEvent(new MouseEvent("click",s)),t instanceof HTMLElement&&t.click(),await c(g.CLICK_SETTLE_TIME)}async function Ve(e){const t=await x(e);if(!t)return;await F(t);const n=t.getBoundingClientRect(),o=n.left+n.width/2,a=n.top+n.height/2;_(o,a),M(),await c(50),M(),t.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0,cancelable:!0,view:window,clientX:o,clientY:a})),await c(g.CLICK_SETTLE_TIME)}async function je(e){if(!e.key)return;console.log("[Replayer] KeyDown:",e.key);let t=null;if(e.selector&&(t=await x(e)),t||(t=document.activeElement),(!t||t===document.body)&&(console.warn("[Replayer] No target for keydown, trying to find input"),t=document.querySelector("input:focus, textarea:focus")||document.activeElement),!t){console.warn("[Replayer] No target element for key:",e.key);return}const n=new KeyboardEvent("keydown",{key:e.key,code:de(e.key),keyCode:e.keyCode||K(e.key),which:e.keyCode||K(e.key),bubbles:!0,cancelable:!0,composed:!0});if(t.dispatchEvent(n),t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){if(e.key.length===1){const o=t.selectionStart??t.value.length,a=t.selectionEnd??t.value.length,s=t.value.substring(0,o),u=t.value.substring(a);t.value=s+e.key+u,t.selectionStart=t.selectionEnd=o+1,t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e.key}))}else if(e.key==="Backspace"){const o=t.selectionStart??t.value.length,a=t.selectionEnd??t.value.length;o===a&&o>0?(t.value=t.value.substring(0,o-1)+t.value.substring(a),t.selectionStart=t.selectionEnd=o-1):o!==a&&(t.value=t.value.substring(0,o)+t.value.substring(a),t.selectionStart=t.selectionEnd=o),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"deleteContentBackward"}))}else if(e.key==="Delete"){const o=t.selectionStart??0,a=t.selectionEnd??0;o===a&&o<t.value.length?t.value=t.value.substring(0,o)+t.value.substring(a+1):o!==a&&(t.value=t.value.substring(0,o)+t.value.substring(a)),t.selectionStart=t.selectionEnd=o,t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"deleteContentForward"}))}}if(e.key==="Enter"&&t){const o=t.closest("form");if(o){await c(50);const a=o.querySelector('button[type="submit"], input[type="submit"]');a instanceof HTMLElement?a.click():o.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0}))}}await c(g.KEY_DELAY)}async function We(e){if(!e.key)return;(document.activeElement||document.body).dispatchEvent(new KeyboardEvent("keyup",{key:e.key,code:de(e.key),keyCode:e.keyCode,bubbles:!0,cancelable:!0})),await c(10)}async function Je(e){console.log("[Replayer] Focus:",e.selector);const t=await x(e);if(!t){console.warn("[Replayer] Element not found for focus");return}await F(t);const n=t.getBoundingClientRect();_(n.left+n.width/2,n.top+n.height/2),M(),t.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0})),t.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0})),t.dispatchEvent(new MouseEvent("click",{bubbles:!0})),t.focus(),t.dispatchEvent(new FocusEvent("focus",{bubbles:!1})),t.dispatchEvent(new FocusEvent("focusin",{bubbles:!0})),(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)&&t.select(),await c(50)}async function Ze(e){console.log("[Replayer] Blur:",e.selector);const t=e.selector?await x(e):document.activeElement;t instanceof HTMLElement&&(t.dispatchEvent(new FocusEvent("blur",{bubbles:!1})),t.dispatchEvent(new FocusEvent("focusout",{bubbles:!0})),t.blur()),await c(30)}async function Qe(e){console.log("[Replayer] Change:",e.selector);const t=await x(e);t&&(e.value!==void 0&&(t.value=e.value),t.dispatchEvent(new Event("change",{bubbles:!0})),await c(30))}async function et(e){await ue(e.scrollX??0,e.scrollY??0)}async function tt(e){console.log("[Replayer] Submit:",e.selector);const t=await x(e);if(!t)return;document.activeElement instanceof HTMLElement&&(document.activeElement.blur(),await c(50));const n=t.querySelector('button[type="submit"], input[type="submit"], button:not([type])');n instanceof HTMLElement?n.click():t.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0})),await c(g.CLICK_SETTLE_TIME)}async function nt(e){e.url&&e.url!==window.location.href&&(console.log("[Replayer] Navigate:",e.url),window.location.href=e.url,await c(1e3))}function de(e){const t={Enter:"Enter",Tab:"Tab",Escape:"Escape",Backspace:"Backspace",Delete:"Delete",ArrowUp:"ArrowUp",ArrowDown:"ArrowDown",ArrowLeft:"ArrowLeft",ArrowRight:"ArrowRight"," ":"Space"};if(t[e])return t[e];if(e.length===1){if(e>="a"&&e<="z")return`Key${e.toUpperCase()}`;if(e>="A"&&e<="Z")return`Key${e}`;if(e>="0"&&e<="9")return`Digit${e}`}return e}function K(e){if(e.length===1){const n=e.toUpperCase().charCodeAt(0);if(n>=65&&n<=90||n>=48&&n<=57)return n}return{Enter:13,Tab:9,Escape:27,Backspace:8,Delete:46,ArrowUp:38,ArrowDown:40,ArrowLeft:37,ArrowRight:39," ":32}[e]||0}async function ot(e){if(!O)switch(e.x!==void 0&&e.y!==void 0&&_(e.x,e.y),e.type){case"click":await Ge(e);break;case"dblclick":await Ve(e);break;case"keydown":await je(e);break;case"keyup":await We(e);break;case"focus":await Je(e);break;case"blur":await Ze(e);break;case"change":await Qe(e);break;case"scroll":await et(e);break;case"submit":await tt(e);break;case"navigate":await nt(e);break}}async function pe(e,t){console.log("[Replayer] Starting:",e.name),console.log("[Replayer] Events:",e.events?.length),I=!0,O=!1;const n=e.events;if(!n||n.length===0)return{success:!1,error:"No events to replay",eventsCompleted:0};Oe(),console.log(`[Replayer] Waiting ${g.INITIAL_DELAY}ms...`),await c(g.INITIAL_DELAY);let o=0;try{for(let a=0;a<n.length;a++){if(O)return{success:!1,error:"Stopped by user",eventsCompleted:o};const s=n[a],u=n[a-1];if(u){const i=s.timestamp-u.timestamp,k=Math.min(Math.max(i,g.MIN_EVENT_GAP),3e3);await c(k)}console.log(`[Replayer] ${a+1}/${n.length}: ${s.type}${s.key?` (${s.key})`:""}`),await ot(s),o=a+1,t?.(o,n.length)}return console.log("[Replayer] Complete!"),await c(300),B(),I=!1,{success:!0,eventsCompleted:o}}catch(a){return console.error("[Replayer] Error:",a),B(),I=!1,{success:!1,error:a instanceof Error?a.message:"Unknown error",eventsCompleted:o}}}function at(){O=!0,I=!1,B()}console.log("[Openmation] Content script loaded on:",window.location.href);const U="https://api.openmation.dev";ze();rt();chrome.runtime.onMessage.addListener((e,t,n)=>(console.log("[Openmation] Content received:",e.type),st(e).then(n).catch(o=>{console.error("[Openmation] Error:",o),n({success:!1,error:o.message})}),!0));window.addEventListener("message",e=>{if(e.source===window&&!(!e.data||!e.data.type))switch(e.data.type){case"OPENMATION_START_RECORDING":chrome.runtime.sendMessage({type:"START_RECORDING_FROM_PANEL"});break;case"OPENMATION_CHECK_EXTENSION":console.log("[Openmation] Extension check received, responding..."),window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*");break;case"OPENMATION_RUN_SHARED":console.log("[Openmation] Received SIMPLEST_RUN_SHARED:",e.data.automationId),e.data.automationId&&it(e.data.automationId);break}});setTimeout(()=>{window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*")},100);async function st(e){switch(e.type){case"PING":return{success:!0,loaded:!0};case"INJECT_PANEL":return console.log("[Openmation] Creating panel..."),ve(),{success:!0};case"REMOVE_PANEL":return C(),{success:!0};case"START_RECORDING":{const t=e.sessionId||crypto.randomUUID();z(t),P({mode:"recording",eventCount:0,duration:0,startTime:Date.now()});const n=document.getElementById("openmation-panel");if(n){const o=n.querySelector(".sa-start-view"),a=n.querySelector(".sa-recording-view");o&&(o.style.display="none"),a&&(a.style.display="block")}return{success:!0,sessionId:t}}case"RESTORE_RECORDING_STATE":{const{sessionId:t,eventCount:n,duration:o,isPaused:a}=e;return z(t),we(n,o,a),{success:!0}}case"PAUSE_RECORDING":return Ye(),P({mode:"paused"}),{success:!0};case"RESUME_RECORDING":return Fe(),P({mode:"recording"}),{success:!0};case"STOP_RECORDING":return{success:!0,...Xe()};case"GET_RECORDING_STATE":return{success:!0,state:He()};case"RUN_AUTOMATION":{const t=e.automation;return t?(pe(t,(n,o)=>{chrome.runtime.sendMessage({type:"AUTOMATION_PROGRESS",runId:t.id,eventsCompleted:n,totalEvents:o,status:"running"}).catch(()=>{})}).then(n=>{chrome.runtime.sendMessage({type:"AUTOMATION_COMPLETE",runId:t.id,status:n.success?"success":"failed",error:n.error,eventsCompleted:n.eventsCompleted}).catch(()=>{})}),{success:!0,message:"Replay started"}):{success:!1,error:"No automation provided"}}case"STOP_AUTOMATION":return at(),{success:!0};default:return{success:!1,error:"Unknown message type"}}}function rt(){const t=window.location.href.match(/\/run\/([a-zA-Z0-9_-]+)$/);if(t){const n=t[1];console.log("[Openmation] Detected shared automation page:",n),setTimeout(()=>{window.postMessage({type:"OPENMATION_EXTENSION_READY"},"*")},100)}}async function it(e){console.log("[Openmation] Running shared automation:",e);try{console.log("[Openmation] Fetching from:",`${U}/api/automations/${e}`);const t=await fetch(`${U}/api/automations/${e}`),n=await t.json();if(console.log("[Openmation] API response:",n),!t.ok||!n.success){console.error("[Openmation] Failed to fetch automation:",n.error),alert("Failed to load automation: "+(n.error||"Unknown error"));return}const o=n.automation;console.log("[Openmation] Automation loaded:",o.name,"startUrl:",o.startUrl),o.startUrl&&!window.location.href.startsWith(o.startUrl.split("?")[0])?(console.log("[Openmation] Storing automation and redirecting to:",o.startUrl),sessionStorage.setItem("openmation_pending_automation",JSON.stringify(o)),window.location.href=o.startUrl):(console.log("[Openmation] Already on target page, running immediately"),fe(o))}catch(t){console.error("[Openmation] Error running shared automation:",t),alert("Failed to run automation. Please try again.")}}function fe(e){if(console.log("[Openmation] Executing automation:",e.name),console.log("[Openmation] Events count:",e.events?.length),console.log("[Openmation] First event:",e.events?.[0]),!e.events||e.events.length===0){console.error("[Openmation] No events in automation!");return}pe(e,(t,n)=>{console.log(`[Openmation] Progress: ${t}/${n}`)}).then(t=>{t.success?console.log("[Openmation] Automation completed successfully"):console.error("[Openmation] Automation failed:",t.error)}).catch(t=>{console.error("[Openmation] Replay error:",t)})}async function ct(){if(window.location.href.includes("api.openmation.dev/run/")){console.log("[Openmation] On run page, skipping pending check");return}const t=window.location.hash.match(/openmation_run=([a-zA-Z0-9_-]+)/);if(t){const n=t[1];console.log("[Openmation] Found automation ID in URL:",n),history.replaceState(null,"",window.location.pathname+window.location.search);try{console.log("[Openmation] Fetching automation from API...");const a=await(await fetch(`${U}/api/automations/${n}`)).json();a.success&&a.automation?(console.log("[Openmation] Fetched automation, executing:",a.automation.name),setTimeout(()=>{fe(a.automation)},1500)):(console.error("[Openmation] Failed to fetch automation:",a.error),alert("Failed to load automation. It may have expired."))}catch(o){console.error("[Openmation] Error fetching automation:",o),alert("Failed to connect to automation server.")}return}}setTimeout(ct,500);
